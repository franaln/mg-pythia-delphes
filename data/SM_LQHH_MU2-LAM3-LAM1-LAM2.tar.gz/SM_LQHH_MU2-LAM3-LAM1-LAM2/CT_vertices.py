# This file was automatically created by FeynRules 2.3.48
# Mathematica version: 11.0.0 for Linux x86 (64-bit) (July 28, 2016)
# Date: Fri 8 Jul 2022 14:27:20


from object_library import all_vertices, all_CTvertices, Vertex, CTVertex
import particles as P
import CT_couplings as C
import lorentz as L


V_1 = CTVertex(name = 'V_1',
               type = 'R2',
               particles = [ P.g, P.g, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVV1, L.VVV2, L.VVV4, L.VVV6, L.VVV7, L.VVV8 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ] ],
               couplings = {(0,0,0):C.R2GC_391_297,(0,0,1):C.R2GC_391_298,(0,1,0):C.R2GC_394_299,(0,1,1):C.R2GC_394_300,(0,2,0):C.R2GC_394_299,(0,2,1):C.R2GC_394_300,(0,3,0):C.R2GC_391_297,(0,3,1):C.R2GC_391_298,(0,4,0):C.R2GC_391_297,(0,4,1):C.R2GC_391_298,(0,5,0):C.R2GC_394_299,(0,5,1):C.R2GC_394_300})

V_2 = CTVertex(name = 'V_2',
               type = 'R2',
               particles = [ P.g, P.g, P.g, P.g ],
               color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
               lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ] ],
               couplings = {(2,0,0):C.R2GC_224_27,(2,0,1):C.R2GC_224_28,(0,0,0):C.R2GC_224_27,(0,0,1):C.R2GC_224_28,(4,0,0):C.R2GC_228_35,(4,0,1):C.R2GC_228_36,(3,0,0):C.R2GC_228_35,(3,0,1):C.R2GC_228_36,(8,0,0):C.R2GC_225_29,(8,0,1):C.R2GC_225_30,(7,0,0):C.R2GC_227_33,(7,0,1):C.R2GC_402_307,(6,0,0):C.R2GC_226_31,(6,0,1):C.R2GC_401_306,(5,0,0):C.R2GC_228_35,(5,0,1):C.R2GC_228_36,(1,0,0):C.R2GC_228_35,(1,0,1):C.R2GC_228_36,(11,0,0):C.R2GC_223_25,(11,0,1):C.R2GC_223_26,(10,0,0):C.R2GC_223_25,(10,0,1):C.R2GC_223_26,(9,0,1):C.R2GC_216_3,(2,1,0):C.R2GC_224_27,(2,1,1):C.R2GC_224_28,(0,1,0):C.R2GC_224_27,(0,1,1):C.R2GC_224_28,(6,1,0):C.R2GC_398_302,(6,1,1):C.R2GC_398_303,(4,1,0):C.R2GC_228_35,(4,1,1):C.R2GC_228_36,(3,1,0):C.R2GC_228_35,(3,1,1):C.R2GC_228_36,(8,1,0):C.R2GC_225_29,(8,1,1):C.R2GC_400_305,(7,1,0):C.R2GC_227_33,(7,1,1):C.R2GC_227_34,(5,1,0):C.R2GC_228_35,(5,1,1):C.R2GC_228_36,(1,1,0):C.R2GC_228_35,(1,1,1):C.R2GC_228_36,(11,1,0):C.R2GC_223_25,(11,1,1):C.R2GC_223_26,(10,1,0):C.R2GC_223_25,(10,1,1):C.R2GC_223_26,(9,1,1):C.R2GC_216_3,(2,2,0):C.R2GC_224_27,(2,2,1):C.R2GC_224_28,(0,2,0):C.R2GC_224_27,(0,2,1):C.R2GC_224_28,(4,2,0):C.R2GC_228_35,(4,2,1):C.R2GC_228_36,(3,2,0):C.R2GC_228_35,(3,2,1):C.R2GC_228_36,(8,2,0):C.R2GC_225_29,(8,2,1):C.R2GC_397_301,(6,2,0):C.R2GC_226_31,(6,2,1):C.R2GC_226_32,(7,2,0):C.R2GC_399_304,(7,2,1):C.R2GC_224_28,(5,2,0):C.R2GC_228_35,(5,2,1):C.R2GC_228_36,(1,2,0):C.R2GC_228_35,(1,2,1):C.R2GC_228_36,(11,2,0):C.R2GC_223_25,(11,2,1):C.R2GC_223_26,(10,2,0):C.R2GC_223_25,(10,2,1):C.R2GC_223_26,(9,2,1):C.R2GC_216_3})

V_3 = CTVertex(name = 'V_3',
               type = 'R2',
               particles = [ P.t__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               loop_particles = [ [ [P.b, P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_366_276,(0,1,0):C.R2GC_367_277})

V_4 = CTVertex(name = 'V_4',
               type = 'R2',
               particles = [ P.c__tilde__, P.d, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               loop_particles = [ [ [P.c, P.d, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_337_257,(0,1,0):C.R2GC_336_256})

V_5 = CTVertex(name = 'V_5',
               type = 'R2',
               particles = [ P.u__tilde__, P.d, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               loop_particles = [ [ [P.d, P.g, P.u] ] ],
               couplings = {(0,0,0):C.R2GC_383_288,(0,1,0):C.R2GC_384_289})

V_6 = CTVertex(name = 'V_6',
               type = 'R2',
               particles = [ P.c__tilde__, P.s, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               loop_particles = [ [ [P.c, P.g, P.s] ] ],
               couplings = {(0,0,0):C.R2GC_353_268,(0,1,0):C.R2GC_352_267})

V_7 = CTVertex(name = 'V_7',
               type = 'R2',
               particles = [ P.u__tilde__, P.s, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3, L.FFS4 ],
               loop_particles = [ [ [P.g, P.s, P.u] ] ],
               couplings = {(0,0,0):C.R2GC_386_291,(0,1,0):C.R2GC_387_292})

V_8 = CTVertex(name = 'V_8',
               type = 'R2',
               particles = [ P.b__tilde__, P.b, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.b, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_315_243})

V_9 = CTVertex(name = 'V_9',
               type = 'R2',
               particles = [ P.d__tilde__, P.d, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.d, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_333_253})

V_10 = CTVertex(name = 'V_10',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.G0 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_349_264})

V_11 = CTVertex(name = 'V_11',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_314_242})

V_12 = CTVertex(name = 'V_12',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_332_252})

V_13 = CTVertex(name = 'V_13',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_348_263})

V_14 = CTVertex(name = 'V_14',
                type = 'R2',
                particles = [ P.d__tilde__, P.c, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3, L.FFS4 ],
                loop_particles = [ [ [P.c, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_331_251,(0,1,0):C.R2GC_334_254})

V_15 = CTVertex(name = 'V_15',
                type = 'R2',
                particles = [ P.s__tilde__, P.c, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3, L.FFS4 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_347_262,(0,1,0):C.R2GC_350_265})

V_16 = CTVertex(name = 'V_16',
                type = 'R2',
                particles = [ P.b__tilde__, P.t, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3, L.FFS4 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_364_274,(0,1,0):C.R2GC_361_271})

V_17 = CTVertex(name = 'V_17',
                type = 'R2',
                particles = [ P.d__tilde__, P.u, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3, L.FFS4 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_380_285,(0,1,0):C.R2GC_376_281})

V_18 = CTVertex(name = 'V_18',
                type = 'R2',
                particles = [ P.s__tilde__, P.u, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3, L.FFS4 ],
                loop_particles = [ [ [P.g, P.s, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_381_286,(0,1,0):C.R2GC_377_282})

V_19 = CTVertex(name = 'V_19',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.G0 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_322_247})

V_20 = CTVertex(name = 'V_20',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.G0 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_362_272})

V_21 = CTVertex(name = 'V_21',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.G0 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_378_283})

V_22 = CTVertex(name = 'V_22',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_323_248})

V_23 = CTVertex(name = 'V_23',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_363_273})

V_24 = CTVertex(name = 'V_24',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_379_284})

V_25 = CTVertex(name = 'V_25',
                type = 'R2',
                particles = [ P.a, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_240_52})

V_26 = CTVertex(name = 'V_26',
                type = 'R2',
                particles = [ P.g, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_242_54})

V_27 = CTVertex(name = 'V_27',
                type = 'R2',
                particles = [ P.a, P.a, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_241_53})

V_28 = CTVertex(name = 'V_28',
                type = 'R2',
                particles = [ P.a, P.g, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'T(2,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_243_55})

V_29 = CTVertex(name = 'V_29',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_245_58})

V_30 = CTVertex(name = 'V_30',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_245_58})

V_31 = CTVertex(name = 'V_31',
                type = 'R2',
                particles = [ P.H, P.H, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_245_58})

V_32 = CTVertex(name = 'V_32',
                type = 'R2',
                particles = [ P.H, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_251_64})

V_33 = CTVertex(name = 'V_33',
                type = 'R2',
                particles = [ P.g, P.g, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.Xd1] ] ],
                couplings = {(2,0,0):C.R2GC_244_56,(2,0,1):C.R2GC_244_57,(1,0,0):C.R2GC_244_56,(1,0,1):C.R2GC_244_57,(0,0,0):C.R2GC_223_26,(0,0,1):C.R2GC_238_50})

V_34 = CTVertex(name = 'V_34',
                type = 'R2',
                particles = [ P.g, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_242_54})

V_35 = CTVertex(name = 'V_35',
                type = 'R2',
                particles = [ P.a, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_240_52})

V_36 = CTVertex(name = 'V_36',
                type = 'R2',
                particles = [ P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_432_340})

V_37 = CTVertex(name = 'V_37',
                type = 'R2',
                particles = [ P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_429_335})

V_38 = CTVertex(name = 'V_38',
                type = 'R2',
                particles = [ P.g, P.g, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.Xd2] ] ],
                couplings = {(2,0,0):C.R2GC_244_56,(2,0,1):C.R2GC_244_57,(1,0,0):C.R2GC_244_56,(1,0,1):C.R2GC_244_57,(0,0,0):C.R2GC_223_26,(0,0,1):C.R2GC_238_50})

V_39 = CTVertex(name = 'V_39',
                type = 'R2',
                particles = [ P.a, P.g, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'T(2,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_243_55})

V_40 = CTVertex(name = 'V_40',
                type = 'R2',
                particles = [ P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_433_341})

V_41 = CTVertex(name = 'V_41',
                type = 'R2',
                particles = [ P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_428_334})

V_42 = CTVertex(name = 'V_42',
                type = 'R2',
                particles = [ P.a, P.a, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_241_53})

V_43 = CTVertex(name = 'V_43',
                type = 'R2',
                particles = [ P.W__minus__, P.W__plus__, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_284_82,(0,0,1):C.R2GC_284_83,(0,0,2):C.R2GC_284_84})

V_44 = CTVertex(name = 'V_44',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_259_65})

V_45 = CTVertex(name = 'V_45',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_259_65})

V_46 = CTVertex(name = 'V_46',
                type = 'R2',
                particles = [ P.H, P.H, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_259_65})

V_47 = CTVertex(name = 'V_47',
                type = 'R2',
                particles = [ P.H, P.Xd2__tilde__, P.Xd2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ] ],
                couplings = {(0,0,0):C.R2GC_265_71})

V_48 = CTVertex(name = 'V_48',
                type = 'R2',
                particles = [ P.a, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_411_318})

V_49 = CTVertex(name = 'V_49',
                type = 'R2',
                particles = [ P.G__plus__, P.Xd2, P.Xu1__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_405_311})

V_50 = CTVertex(name = 'V_50',
                type = 'R2',
                particles = [ P.g, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_415_320})

V_51 = CTVertex(name = 'V_51',
                type = 'R2',
                particles = [ P.g, P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                color = [ 'T(1,3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_435_343,(0,0,2):C.R2GC_435_344,(0,0,1):C.R2GC_435_345})

V_52 = CTVertex(name = 'V_52',
                type = 'R2',
                particles = [ P.a, P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_434_342})

V_53 = CTVertex(name = 'V_53',
                type = 'R2',
                particles = [ P.a, P.a, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_413_319})

V_54 = CTVertex(name = 'V_54',
                type = 'R2',
                particles = [ P.a, P.g, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'T(2,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_417_321})

V_55 = CTVertex(name = 'V_55',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_421_324})

V_56 = CTVertex(name = 'V_56',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_421_324})

V_57 = CTVertex(name = 'V_57',
                type = 'R2',
                particles = [ P.H, P.H, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_421_324})

V_58 = CTVertex(name = 'V_58',
                type = 'R2',
                particles = [ P.H, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_454_364})

V_59 = CTVertex(name = 'V_59',
                type = 'R2',
                particles = [ P.G__minus__, P.Xd2__tilde__, P.Xu1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_406_312})

V_60 = CTVertex(name = 'V_60',
                type = 'R2',
                particles = [ P.g, P.g, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.Xu1] ] ],
                couplings = {(2,0,0):C.R2GC_419_322,(2,0,1):C.R2GC_419_323,(1,0,0):C.R2GC_419_322,(1,0,1):C.R2GC_419_323,(0,0,0):C.R2GC_266_72,(0,0,1):C.R2GC_266_73})

V_61 = CTVertex(name = 'V_61',
                type = 'R2',
                particles = [ P.g, P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                color = [ 'T(1,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_435_343,(0,0,2):C.R2GC_435_344,(0,0,1):C.R2GC_435_345})

V_62 = CTVertex(name = 'V_62',
                type = 'R2',
                particles = [ P.a, P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_434_342})

V_63 = CTVertex(name = 'V_63',
                type = 'R2',
                particles = [ P.W__minus__, P.W__plus__, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,1):C.R2GC_427_332,(0,0,0):C.R2GC_427_333})

V_64 = CTVertex(name = 'V_64',
                type = 'R2',
                particles = [ P.a, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_411_318})

V_65 = CTVertex(name = 'V_65',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_66 = CTVertex(name = 'V_66',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_67 = CTVertex(name = 'V_67',
                type = 'R2',
                particles = [ P.H, P.H, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_68 = CTVertex(name = 'V_68',
                type = 'R2',
                particles = [ P.H, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_453_363})

V_69 = CTVertex(name = 'V_69',
                type = 'R2',
                particles = [ P.G0, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_423_326})

V_70 = CTVertex(name = 'V_70',
                type = 'R2',
                particles = [ P.G__plus__, P.Xd2, P.Xu2__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_408_314})

V_71 = CTVertex(name = 'V_71',
                type = 'R2',
                particles = [ P.g, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_415_320})

V_72 = CTVertex(name = 'V_72',
                type = 'R2',
                particles = [ P.g, P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                color = [ 'T(1,3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_431_337,(0,0,2):C.R2GC_431_338,(0,0,1):C.R2GC_431_339})

V_73 = CTVertex(name = 'V_73',
                type = 'R2',
                particles = [ P.a, P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_430_336})

V_74 = CTVertex(name = 'V_74',
                type = 'R2',
                particles = [ P.W__minus__, P.W__plus__, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,1):C.R2GC_426_330,(0,0,0):C.R2GC_426_331})

V_75 = CTVertex(name = 'V_75',
                type = 'R2',
                particles = [ P.a, P.a, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_413_319})

V_76 = CTVertex(name = 'V_76',
                type = 'R2',
                particles = [ P.a, P.g, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'T(2,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_417_321})

V_77 = CTVertex(name = 'V_77',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_78 = CTVertex(name = 'V_78',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_79 = CTVertex(name = 'V_79',
                type = 'R2',
                particles = [ P.H, P.H, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_407_313})

V_80 = CTVertex(name = 'V_80',
                type = 'R2',
                particles = [ P.H, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_453_363})

V_81 = CTVertex(name = 'V_81',
                type = 'R2',
                particles = [ P.G0, P.G0, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_422_325})

V_82 = CTVertex(name = 'V_82',
                type = 'R2',
                particles = [ P.G__minus__, P.G__plus__, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_422_325})

V_83 = CTVertex(name = 'V_83',
                type = 'R2',
                particles = [ P.H, P.H, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.SSSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_422_325})

V_84 = CTVertex(name = 'V_84',
                type = 'R2',
                particles = [ P.H, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_455_365})

V_85 = CTVertex(name = 'V_85',
                type = 'R2',
                particles = [ P.G__minus__, P.Xd2__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_409_315})

V_86 = CTVertex(name = 'V_86',
                type = 'R2',
                particles = [ P.G0, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_424_327})

V_87 = CTVertex(name = 'V_87',
                type = 'R2',
                particles = [ P.g, P.g, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.Xu2] ] ],
                couplings = {(2,0,0):C.R2GC_419_322,(2,0,1):C.R2GC_419_323,(1,0,0):C.R2GC_419_322,(1,0,1):C.R2GC_419_323,(0,0,0):C.R2GC_266_72,(0,0,1):C.R2GC_266_73})

V_88 = CTVertex(name = 'V_88',
                type = 'R2',
                particles = [ P.g, P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                color = [ 'T(1,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_431_337,(0,0,2):C.R2GC_431_338,(0,0,1):C.R2GC_431_339})

V_89 = CTVertex(name = 'V_89',
                type = 'R2',
                particles = [ P.a, P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_430_336})

V_90 = CTVertex(name = 'V_90',
                type = 'R2',
                particles = [ P.W__minus__, P.W__plus__, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,1):C.R2GC_426_330,(0,0,0):C.R2GC_426_331})

V_91 = CTVertex(name = 'V_91',
                type = 'R2',
                particles = [ P.W__minus__, P.W__plus__, P.Xu2__tilde__, P.Xu2 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                couplings = {(0,0,1):C.R2GC_425_328,(0,0,0):C.R2GC_425_329})

V_92 = CTVertex(name = 'V_92',
                type = 'R2',
                particles = [ P.Z, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS1, L.VSS3 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_247_60,(0,1,0):C.R2GC_246_59})

V_93 = CTVertex(name = 'V_93',
                type = 'R2',
                particles = [ P.a, P.Z, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_248_61})

V_94 = CTVertex(name = 'V_94',
                type = 'R2',
                particles = [ P.g, P.Z, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'T(1,4,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_249_62})

V_95 = CTVertex(name = 'V_95',
                type = 'R2',
                particles = [ P.Z, P.Z, P.Xd1__tilde__, P.Xd1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xd1] ] ],
                couplings = {(0,0,0):C.R2GC_250_63})

V_96 = CTVertex(name = 'V_96',
                type = 'R2',
                particles = [ P.Z, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS1, L.VSS3 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_443_352,(0,1,0):C.R2GC_442_351})

V_97 = CTVertex(name = 'V_97',
                type = 'R2',
                particles = [ P.Z, P.Xu1__tilde__, P.Xu2 ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS1, L.VSS3 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_436_346,(0,1,0):C.R2GC_438_347})

V_98 = CTVertex(name = 'V_98',
                type = 'R2',
                particles = [ P.Z, P.Xu1, P.Xu2__tilde__ ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VSS1, L.VSS3 ],
                loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                couplings = {(0,0,0):C.R2GC_438_347,(0,1,0):C.R2GC_436_346})

V_99 = CTVertex(name = 'V_99',
                type = 'R2',
                particles = [ P.a, P.Z, P.Xu1__tilde__, P.Xu1 ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g, P.Xu1] ] ],
                couplings = {(0,0,0):C.R2GC_446_355})

V_100 = CTVertex(name = 'V_100',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1] ] ],
                 couplings = {(0,0,0):C.R2GC_448_357})

V_101 = CTVertex(name = 'V_101',
                 type = 'R2',
                 particles = [ P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_445_354,(0,1,0):C.R2GC_444_353})

V_102 = CTVertex(name = 'V_102',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_440_348})

V_103 = CTVertex(name = 'V_103',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1], [P.g, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_441_349,(0,0,1):C.R2GC_441_350})

V_104 = CTVertex(name = 'V_104',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_440_348})

V_105 = CTVertex(name = 'V_105',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1], [P.g, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_441_349,(0,0,1):C.R2GC_441_350})

V_106 = CTVertex(name = 'V_106',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_447_356})

V_107 = CTVertex(name = 'V_107',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_449_358})

V_108 = CTVertex(name = 'V_108',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_451_360,(0,0,1):C.R2GC_451_361})

V_109 = CTVertex(name = 'V_109',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_450_359})

V_110 = CTVertex(name = 'V_110',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_450_359})

V_111 = CTVertex(name = 'V_111',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,1):C.R2GC_452_362,(0,0,0):C.R2GC_451_361})

V_112 = CTVertex(name = 'V_112',
                 type = 'R2',
                 particles = [ P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.R2GC_260_66,(0,1,0):C.R2GC_261_67})

V_113 = CTVertex(name = 'V_113',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.R2GC_263_69})

V_114 = CTVertex(name = 'V_114',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.R2GC_262_68})

V_115 = CTVertex(name = 'V_115',
                 type = 'R2',
                 particles = [ P.W__plus__, P.Z, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_410_316,(0,0,1):C.R2GC_410_317})

V_116 = CTVertex(name = 'V_116',
                 type = 'R2',
                 particles = [ P.W__minus__, P.Z, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_410_316,(0,0,1):C.R2GC_410_317})

V_117 = CTVertex(name = 'V_117',
                 type = 'R2',
                 particles = [ P.W__plus__, P.Z, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ] ],
                 couplings = {(0,0,1):C.R2GC_404_309,(0,0,0):C.R2GC_404_310})

V_118 = CTVertex(name = 'V_118',
                 type = 'R2',
                 particles = [ P.W__minus__, P.Z, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ] ],
                 couplings = {(0,0,1):C.R2GC_404_309,(0,0,0):C.R2GC_404_310})

V_119 = CTVertex(name = 'V_119',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.R2GC_264_70})

V_120 = CTVertex(name = 'V_120',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_234_49})

V_121 = CTVertex(name = 'V_121',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_234_49})

V_122 = CTVertex(name = 'V_122',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_234_49})

V_123 = CTVertex(name = 'V_123',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_232_47})

V_124 = CTVertex(name = 'V_124',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_232_47})

V_125 = CTVertex(name = 'V_125',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_232_47})

V_126 = CTVertex(name = 'V_126',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_127 = CTVertex(name = 'V_127',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_128 = CTVertex(name = 'V_128',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_129 = CTVertex(name = 'V_129',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_130 = CTVertex(name = 'V_130',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_131 = CTVertex(name = 'V_131',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_233_48})

V_132 = CTVertex(name = 'V_132',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_328_250})

V_133 = CTVertex(name = 'V_133',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_344_261})

V_134 = CTVertex(name = 'V_134',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_358_270})

V_135 = CTVertex(name = 'V_135',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_372_279})

V_136 = CTVertex(name = 'V_136',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.g, P.s, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_373_280})

V_137 = CTVertex(name = 'V_137',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_365_275})

V_138 = CTVertex(name = 'V_138',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_335_255})

V_139 = CTVertex(name = 'V_139',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_382_287})

V_140 = CTVertex(name = 'V_140',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_351_266})

V_141 = CTVertex(name = 'V_141',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.g, P.s, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_385_290})

V_142 = CTVertex(name = 'V_142',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_320_245,(0,1,0):C.R2GC_321_246})

V_143 = CTVertex(name = 'V_143',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_320_245,(0,1,0):C.R2GC_321_246})

V_144 = CTVertex(name = 'V_144',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_320_245,(0,1,0):C.R2GC_321_246})

V_145 = CTVertex(name = 'V_145',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_312_240,(0,1,0):C.R2GC_313_241})

V_146 = CTVertex(name = 'V_146',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_312_240,(0,1,0):C.R2GC_313_241})

V_147 = CTVertex(name = 'V_147',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_312_240,(0,1,0):C.R2GC_313_241})

V_148 = CTVertex(name = 'V_148',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_311_239,(0,2,0):C.R2GC_311_239,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_149 = CTVertex(name = 'V_149',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_319_244,(0,2,0):C.R2GC_319_244,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_150 = CTVertex(name = 'V_150',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_327_249,(0,2,0):C.R2GC_327_249,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_151 = CTVertex(name = 'V_151',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_343_260,(0,2,0):C.R2GC_343_260,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_152 = CTVertex(name = 'V_152',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_357_269,(0,2,0):C.R2GC_357_269,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_153 = CTVertex(name = 'V_153',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_371_278,(0,2,0):C.R2GC_371_278,(0,1,0):C.R2GC_308_238,(0,3,0):C.R2GC_308_238})

V_154 = CTVertex(name = 'V_154',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.R2GC_338_258,(0,1,0):C.R2GC_239_51})

V_155 = CTVertex(name = 'V_155',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xu1] ] ],
                 couplings = {(0,0,0):C.R2GC_388_293,(0,1,0):C.R2GC_269_74})

V_156 = CTVertex(name = 'V_156',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.R2GC_339_259,(0,1,0):C.R2GC_239_51})

V_157 = CTVertex(name = 'V_157',
                 type = 'R2',
                 particles = [ P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.R2GC_403_308,(0,1,0):C.R2GC_269_74})

V_158 = CTVertex(name = 'V_158',
                 type = 'R2',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV2, L.VV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.s] ], [ [P.t] ], [ [P.u] ] ],
                 couplings = {(0,0,4):C.R2GC_390_296,(0,1,0):C.R2GC_217_4,(0,1,2):C.R2GC_217_5,(0,1,3):C.R2GC_217_6,(0,1,5):C.R2GC_217_7,(0,1,6):C.R2GC_217_8,(0,1,7):C.R2GC_217_9,(0,2,1):C.R2GC_389_294,(0,2,4):C.R2GC_389_295})

V_159 = CTVertex(name = 'V_159',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.s] ], [ [P.t] ], [ [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_231_41,(0,0,1):C.R2GC_231_42,(0,0,2):C.R2GC_231_43,(0,0,3):C.R2GC_231_44,(0,0,4):C.R2GC_231_45,(0,0,5):C.R2GC_231_46})

V_160 = CTVertex(name = 'V_160',
                 type = 'R2',
                 particles = [ P.a, P.a, P.g, P.g ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_221_21,(0,0,1):C.R2GC_221_22,(0,1,0):C.R2GC_221_21,(0,1,1):C.R2GC_221_22,(0,2,0):C.R2GC_221_21,(0,2,1):C.R2GC_221_22})

V_161 = CTVertex(name = 'V_161',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.Z ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_229_37,(0,0,1):C.R2GC_229_38,(0,1,0):C.R2GC_229_37,(0,1,1):C.R2GC_229_38,(0,2,0):C.R2GC_229_37,(0,2,1):C.R2GC_229_38})

V_162 = CTVertex(name = 'V_162',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Z, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_282_80,(0,0,1):C.R2GC_282_81,(0,1,0):C.R2GC_282_80,(0,1,1):C.R2GC_282_81,(0,2,0):C.R2GC_282_80,(0,2,1):C.R2GC_282_81})

V_163 = CTVertex(name = 'V_163',
                 type = 'R2',
                 particles = [ P.g, P.g, P.W__minus__, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b, P.t] ], [ [P.c, P.d] ], [ [P.c, P.s] ], [ [P.d, P.u] ], [ [P.s, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_280_75,(0,0,1):C.R2GC_280_76,(0,0,2):C.R2GC_280_77,(0,0,3):C.R2GC_280_78,(0,0,4):C.R2GC_280_79,(0,1,0):C.R2GC_280_75,(0,1,1):C.R2GC_280_76,(0,1,2):C.R2GC_280_77,(0,1,3):C.R2GC_280_78,(0,1,4):C.R2GC_280_79,(0,2,0):C.R2GC_280_75,(0,2,1):C.R2GC_280_76,(0,2,2):C.R2GC_280_77,(0,2,3):C.R2GC_280_78,(0,2,4):C.R2GC_280_79})

V_164 = CTVertex(name = 'V_164',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.g ],
                 color = [ 'd(2,3,4)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_222_23,(0,0,1):C.R2GC_222_24,(0,1,0):C.R2GC_222_23,(0,1,1):C.R2GC_222_24,(0,2,0):C.R2GC_222_23,(0,2,1):C.R2GC_222_24})

V_165 = CTVertex(name = 'V_165',
                 type = 'R2',
                 particles = [ P.g, P.g, P.g, P.Z ],
                 color = [ 'd(1,2,3)', 'f(1,2,3)' ],
                 lorentz = [ L.VVVV1, L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(1,0,0):C.R2GC_210_1,(1,0,1):C.R2GC_210_2,(0,1,0):C.R2GC_230_39,(0,1,1):C.R2GC_230_40,(0,2,0):C.R2GC_230_39,(0,2,1):C.R2GC_230_40,(0,3,0):C.R2GC_230_39,(0,3,1):C.R2GC_230_40})

V_166 = CTVertex(name = 'V_166',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.s] ], [ [P.t] ], [ [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_219_10,(0,0,1):C.R2GC_219_11,(0,0,2):C.R2GC_219_12,(0,0,3):C.R2GC_219_13,(0,0,4):C.R2GC_219_14,(0,0,5):C.R2GC_219_15})

V_167 = CTVertex(name = 'V_167',
                 type = 'R2',
                 particles = [ P.g, P.g, P.G0, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.s] ], [ [P.t] ], [ [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_219_10,(0,0,1):C.R2GC_219_11,(0,0,2):C.R2GC_219_12,(0,0,3):C.R2GC_219_13,(0,0,4):C.R2GC_219_14,(0,0,5):C.R2GC_219_15})

V_168 = CTVertex(name = 'V_168',
                 type = 'R2',
                 particles = [ P.g, P.g, P.G__minus__, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t] ], [ [P.c, P.d] ], [ [P.c, P.s] ], [ [P.d, P.u] ], [ [P.s, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_220_16,(0,0,1):C.R2GC_220_17,(0,0,2):C.R2GC_220_18,(0,0,3):C.R2GC_220_19,(0,0,4):C.R2GC_220_20})

V_169 = CTVertex(name = 'V_169',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1__tilde__, P.Xd1, P.Xd1 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_285_85,(1,0,0):C.R2GC_285_86,(1,0,3):C.R2GC_285_87,(1,0,5):C.R2GC_285_88,(1,0,1):C.R2GC_285_89,(1,0,4):C.R2GC_285_90,(0,0,2):C.R2GC_285_85,(0,0,0):C.R2GC_285_86,(0,0,3):C.R2GC_285_87,(0,0,5):C.R2GC_285_88,(0,0,1):C.R2GC_285_89,(0,0,4):C.R2GC_285_90})

V_170 = CTVertex(name = 'V_170',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.a, P.g, P.Xd1, P.Xu1] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Xu1] ], [ [P.g, P.Xd1, P.Xu1, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.R2GC_292_131,(1,0,0):C.R2GC_292_132,(1,0,5):C.R2GC_292_133,(1,0,9):C.R2GC_292_134,(1,0,11):C.R2GC_292_135,(1,0,1):C.R2GC_292_136,(1,0,3):C.R2GC_292_137,(1,0,6):C.R2GC_292_138,(1,0,8):C.R2GC_292_139,(1,0,10):C.R2GC_292_140,(1,0,2):C.R2GC_292_141,(1,0,7):C.R2GC_292_142,(0,0,4):C.R2GC_291_119,(0,0,0):C.R2GC_291_120,(0,0,5):C.R2GC_291_121,(0,0,9):C.R2GC_291_122,(0,0,11):C.R2GC_291_123,(0,0,1):C.R2GC_291_124,(0,0,3):C.R2GC_291_125,(0,0,6):C.R2GC_291_126,(0,0,8):C.R2GC_291_127,(0,0,10):C.R2GC_291_128,(0,0,2):C.R2GC_291_129,(0,0,7):C.R2GC_291_130})

V_171 = CTVertex(name = 'V_171',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu1, P.Xu1 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_287_93,(1,0,0):C.R2GC_287_94,(1,0,3):C.R2GC_287_95,(1,0,5):C.R2GC_287_96,(1,0,1):C.R2GC_287_97,(1,0,4):C.R2GC_287_98,(0,0,2):C.R2GC_287_93,(0,0,0):C.R2GC_287_94,(0,0,3):C.R2GC_287_95,(0,0,5):C.R2GC_287_96,(0,0,1):C.R2GC_287_97,(0,0,4):C.R2GC_287_98})

V_172 = CTVertex(name = 'V_172',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1], [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd1, P.Xd2] ], [ [P.g] ], [ [P.g, P.Xd1], [P.g, P.Xd2] ], [ [P.g, P.Xd1, P.Xd2] ], [ [P.g, P.Xd1, P.Xd2, P.Z] ], [ [P.g, P.Xd1, P.Z], [P.g, P.Xd2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_290_110,(1,0,0):C.R2GC_290_111,(1,0,4):C.R2GC_290_112,(1,0,8):C.R2GC_290_113,(1,0,1):C.R2GC_290_114,(1,0,5):C.R2GC_290_115,(1,0,7):C.R2GC_290_116,(1,0,2):C.R2GC_290_117,(1,0,6):C.R2GC_290_118,(0,0,3):C.R2GC_289_101,(0,0,0):C.R2GC_289_102,(0,0,4):C.R2GC_289_103,(0,0,8):C.R2GC_289_104,(0,0,1):C.R2GC_289_105,(0,0,5):C.R2GC_289_106,(0,0,7):C.R2GC_289_107,(0,0,2):C.R2GC_289_108,(0,0,6):C.R2GC_289_109})

V_173 = CTVertex(name = 'V_173',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd2, P.Xu1] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1] ], [ [P.g, P.W__plus__, P.Xu1] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.R2GC_292_131,(1,0,0):C.R2GC_292_132,(1,0,5):C.R2GC_302_201,(1,0,9):C.R2GC_292_133,(1,0,13):C.R2GC_292_134,(1,0,15):C.R2GC_302_202,(1,0,1):C.R2GC_292_136,(1,0,3):C.R2GC_292_137,(1,0,6):C.R2GC_302_203,(1,0,8):C.R2GC_302_204,(1,0,10):C.R2GC_292_138,(1,0,12):C.R2GC_302_205,(1,0,14):C.R2GC_302_206,(1,0,2):C.R2GC_292_141,(1,0,7):C.R2GC_302_207,(1,0,11):C.R2GC_302_208,(0,0,4):C.R2GC_291_119,(0,0,0):C.R2GC_291_120,(0,0,5):C.R2GC_301_193,(0,0,9):C.R2GC_291_121,(0,0,13):C.R2GC_291_122,(0,0,15):C.R2GC_301_194,(0,0,1):C.R2GC_291_124,(0,0,3):C.R2GC_291_125,(0,0,6):C.R2GC_301_195,(0,0,8):C.R2GC_301_196,(0,0,10):C.R2GC_291_126,(0,0,12):C.R2GC_301_197,(0,0,14):C.R2GC_301_198,(0,0,2):C.R2GC_291_129,(0,0,7):C.R2GC_301_199,(0,0,11):C.R2GC_301_200})

V_174 = CTVertex(name = 'V_174',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2__tilde__, P.Xd2, P.Xd2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.g] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_285_85,(1,0,0):C.R2GC_285_86,(1,0,3):C.R2GC_285_87,(1,0,5):C.R2GC_286_91,(1,0,1):C.R2GC_285_89,(1,0,4):C.R2GC_286_92,(0,0,2):C.R2GC_285_85,(0,0,0):C.R2GC_285_86,(0,0,3):C.R2GC_285_87,(0,0,5):C.R2GC_286_91,(0,0,1):C.R2GC_285_89,(0,0,4):C.R2GC_286_92})

V_175 = CTVertex(name = 'V_175',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1, P.Xu1, P.Z], [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_294_147,(1,0,1):C.R2GC_294_148,(1,0,2):C.R2GC_294_149,(1,0,0):C.R2GC_294_150,(0,0,3):C.R2GC_293_143,(0,0,1):C.R2GC_293_144,(0,0,2):C.R2GC_293_145,(0,0,0):C.R2GC_293_146})

V_176 = CTVertex(name = 'V_176',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu1, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_304_212,(1,0,1):C.R2GC_304_213,(1,0,2):C.R2GC_304_214,(1,0,0):C.R2GC_304_215,(0,0,3):C.R2GC_304_212,(0,0,1):C.R2GC_304_213,(0,0,2):C.R2GC_304_214,(0,0,0):C.R2GC_304_215})

V_177 = CTVertex(name = 'V_177',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1], [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1], [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Z], [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,0):C.R2GC_300_184,(1,0,8):C.R2GC_300_185,(1,0,1):C.R2GC_300_186,(1,0,3):C.R2GC_300_187,(1,0,6):C.R2GC_300_188,(1,0,7):C.R2GC_300_189,(1,0,2):C.R2GC_300_190,(1,0,4):C.R2GC_300_191,(1,0,5):C.R2GC_300_192,(0,0,0):C.R2GC_299_175,(0,0,8):C.R2GC_299_176,(0,0,1):C.R2GC_299_177,(0,0,3):C.R2GC_299_178,(0,0,6):C.R2GC_299_179,(0,0,7):C.R2GC_299_180,(0,0,2):C.R2GC_299_181,(0,0,4):C.R2GC_299_182,(0,0,5):C.R2GC_299_183})

V_178 = CTVertex(name = 'V_178',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_303_209,(1,0,1):C.R2GC_303_210,(1,0,0):C.R2GC_303_211,(0,0,2):C.R2GC_303_209,(0,0,1):C.R2GC_303_210,(0,0,0):C.R2GC_303_211})

V_179 = CTVertex(name = 'V_179',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1, P.Xu1, P.Z], [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_294_147,(1,0,1):C.R2GC_294_148,(1,0,2):C.R2GC_294_149,(1,0,0):C.R2GC_294_150,(0,0,3):C.R2GC_293_143,(0,0,1):C.R2GC_293_144,(0,0,2):C.R2GC_293_145,(0,0,0):C.R2GC_293_146})

V_180 = CTVertex(name = 'V_180',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_304_212,(1,0,1):C.R2GC_304_213,(1,0,2):C.R2GC_304_214,(1,0,0):C.R2GC_304_215,(0,0,3):C.R2GC_304_212,(0,0,1):C.R2GC_304_213,(0,0,2):C.R2GC_304_214,(0,0,0):C.R2GC_304_215})

V_181 = CTVertex(name = 'V_181',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1], [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1], [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Z], [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,0):C.R2GC_300_184,(1,0,8):C.R2GC_300_185,(1,0,1):C.R2GC_300_186,(1,0,3):C.R2GC_300_187,(1,0,6):C.R2GC_300_188,(1,0,7):C.R2GC_300_189,(1,0,2):C.R2GC_300_190,(1,0,4):C.R2GC_300_191,(1,0,5):C.R2GC_300_192,(0,0,0):C.R2GC_299_175,(0,0,8):C.R2GC_299_176,(0,0,1):C.R2GC_299_177,(0,0,3):C.R2GC_299_178,(0,0,6):C.R2GC_299_179,(0,0,7):C.R2GC_299_180,(0,0,2):C.R2GC_299_181,(0,0,4):C.R2GC_299_182,(0,0,5):C.R2GC_299_183})

V_182 = CTVertex(name = 'V_182',
                 type = 'R2',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.a, P.g, P.Xd1, P.Xu2] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Xu2] ], [ [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.R2GC_292_131,(1,0,0):C.R2GC_292_132,(1,0,5):C.R2GC_292_133,(1,0,9):C.R2GC_292_134,(1,0,11):C.R2GC_296_155,(1,0,1):C.R2GC_292_136,(1,0,3):C.R2GC_292_137,(1,0,6):C.R2GC_292_138,(1,0,8):C.R2GC_296_156,(1,0,10):C.R2GC_296_157,(1,0,2):C.R2GC_292_141,(1,0,7):C.R2GC_296_158,(0,0,4):C.R2GC_291_119,(0,0,0):C.R2GC_291_120,(0,0,5):C.R2GC_291_121,(0,0,9):C.R2GC_291_122,(0,0,11):C.R2GC_295_151,(0,0,1):C.R2GC_291_124,(0,0,3):C.R2GC_291_125,(0,0,6):C.R2GC_291_126,(0,0,8):C.R2GC_295_152,(0,0,10):C.R2GC_295_153,(0,0,2):C.R2GC_291_129,(0,0,7):C.R2GC_295_154})

V_183 = CTVertex(name = 'V_183',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu1, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu1], [P.a, P.g, P.Xu2] ], [ [P.a, P.g, P.Xu1, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xu1], [P.g, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_307_229,(1,0,0):C.R2GC_307_230,(1,0,4):C.R2GC_307_231,(1,0,8):C.R2GC_307_232,(1,0,1):C.R2GC_307_233,(1,0,5):C.R2GC_307_234,(1,0,7):C.R2GC_307_235,(1,0,2):C.R2GC_307_236,(1,0,6):C.R2GC_307_237,(0,0,3):C.R2GC_306_220,(0,0,0):C.R2GC_306_221,(0,0,4):C.R2GC_306_222,(0,0,8):C.R2GC_306_223,(0,0,1):C.R2GC_306_224,(0,0,5):C.R2GC_306_225,(0,0,7):C.R2GC_306_226,(0,0,2):C.R2GC_306_227,(0,0,6):C.R2GC_306_228})

V_184 = CTVertex(name = 'V_184',
                 type = 'R2',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd2, P.Xu2] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.R2GC_292_131,(1,0,0):C.R2GC_292_132,(1,0,5):C.R2GC_298_167,(1,0,9):C.R2GC_292_133,(1,0,13):C.R2GC_292_134,(1,0,15):C.R2GC_298_168,(1,0,1):C.R2GC_292_136,(1,0,3):C.R2GC_292_137,(1,0,6):C.R2GC_298_169,(1,0,8):C.R2GC_298_170,(1,0,10):C.R2GC_292_138,(1,0,12):C.R2GC_298_171,(1,0,14):C.R2GC_298_172,(1,0,2):C.R2GC_292_141,(1,0,7):C.R2GC_298_173,(1,0,11):C.R2GC_298_174,(0,0,4):C.R2GC_291_119,(0,0,0):C.R2GC_291_120,(0,0,5):C.R2GC_297_159,(0,0,9):C.R2GC_291_121,(0,0,13):C.R2GC_291_122,(0,0,15):C.R2GC_297_160,(0,0,1):C.R2GC_291_124,(0,0,3):C.R2GC_291_125,(0,0,6):C.R2GC_297_161,(0,0,8):C.R2GC_297_162,(0,0,10):C.R2GC_291_126,(0,0,12):C.R2GC_297_163,(0,0,14):C.R2GC_297_164,(0,0,2):C.R2GC_291_129,(0,0,7):C.R2GC_297_165,(0,0,11):C.R2GC_297_166})

V_185 = CTVertex(name = 'V_185',
                 type = 'R2',
                 particles = [ P.Xu1__tilde__, P.Xu2__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_305_216,(1,0,1):C.R2GC_305_217,(1,0,2):C.R2GC_305_218,(1,0,0):C.R2GC_305_219,(0,0,3):C.R2GC_305_216,(0,0,1):C.R2GC_305_217,(0,0,2):C.R2GC_305_218,(0,0,0):C.R2GC_305_219})

V_186 = CTVertex(name = 'V_186',
                 type = 'R2',
                 particles = [ P.Xu1, P.Xu1, P.Xu2__tilde__, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_303_209,(1,0,1):C.R2GC_303_210,(1,0,0):C.R2GC_303_211,(0,0,2):C.R2GC_303_209,(0,0,1):C.R2GC_303_210,(0,0,0):C.R2GC_303_211})

V_187 = CTVertex(name = 'V_187',
                 type = 'R2',
                 particles = [ P.Xu1, P.Xu2__tilde__, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.R2GC_305_216,(1,0,1):C.R2GC_305_217,(1,0,2):C.R2GC_305_218,(1,0,0):C.R2GC_305_219,(0,0,3):C.R2GC_305_216,(0,0,1):C.R2GC_305_217,(0,0,2):C.R2GC_305_218,(0,0,0):C.R2GC_305_219})

V_188 = CTVertex(name = 'V_188',
                 type = 'R2',
                 particles = [ P.Xu2__tilde__, P.Xu2__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.R2GC_287_93,(1,0,0):C.R2GC_287_94,(1,0,3):C.R2GC_287_95,(1,0,5):C.R2GC_288_99,(1,0,1):C.R2GC_287_97,(1,0,4):C.R2GC_288_100,(0,0,2):C.R2GC_287_93,(0,0,0):C.R2GC_287_94,(0,0,3):C.R2GC_287_95,(0,0,5):C.R2GC_288_99,(0,0,1):C.R2GC_287_97,(0,0,4):C.R2GC_288_100})

V_189 = CTVertex(name = 'V_189',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g ],
                 color = [ 'f(1,2,3)' ],
                 lorentz = [ L.VVV1, L.VVV2, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd1], [P.Xd2] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu1], [P.Xu2] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_391_486,(0,0,1):C.UVGC_391_487,(0,0,2):C.UVGC_391_488,(0,0,3):C.UVGC_391_489,(0,0,4):C.UVGC_218_12,(0,0,5):C.UVGC_391_490,(0,0,6):C.UVGC_391_491,(0,0,7):C.UVGC_391_492,(0,0,8):C.UVGC_391_493,(0,0,10):C.UVGC_391_494,(0,0,11):C.UVGC_391_495,(0,0,13):C.UVGC_391_496,(0,1,0):C.UVGC_394_505,(0,1,1):C.UVGC_394_506,(0,1,2):C.UVGC_394_507,(0,1,3):C.UVGC_395_516,(0,1,4):C.UVGC_395_517,(0,1,5):C.UVGC_394_509,(0,1,6):C.UVGC_394_510,(0,1,7):C.UVGC_394_511,(0,1,8):C.UVGC_395_518,(0,1,10):C.UVGC_395_519,(0,1,11):C.UVGC_395_520,(0,1,13):C.UVGC_395_521,(0,3,0):C.UVGC_394_505,(0,3,1):C.UVGC_394_506,(0,3,2):C.UVGC_394_507,(0,3,3):C.UVGC_394_508,(0,3,4):C.UVGC_215_6,(0,3,5):C.UVGC_394_509,(0,3,6):C.UVGC_394_510,(0,3,7):C.UVGC_394_511,(0,3,8):C.UVGC_394_512,(0,3,10):C.UVGC_394_513,(0,3,11):C.UVGC_394_514,(0,3,13):C.UVGC_394_515,(0,5,0):C.UVGC_391_486,(0,5,1):C.UVGC_391_487,(0,5,2):C.UVGC_391_488,(0,5,3):C.UVGC_393_499,(0,5,4):C.UVGC_393_500,(0,5,5):C.UVGC_391_490,(0,5,6):C.UVGC_391_491,(0,5,7):C.UVGC_391_492,(0,5,8):C.UVGC_393_501,(0,5,10):C.UVGC_393_502,(0,5,11):C.UVGC_393_503,(0,5,13):C.UVGC_393_504,(0,6,0):C.UVGC_391_486,(0,6,1):C.UVGC_391_487,(0,6,2):C.UVGC_391_488,(0,6,3):C.UVGC_392_497,(0,6,4):C.UVGC_392_498,(0,6,5):C.UVGC_391_490,(0,6,6):C.UVGC_391_491,(0,6,7):C.UVGC_391_492,(0,6,8):C.UVGC_391_493,(0,6,10):C.UVGC_391_494,(0,6,11):C.UVGC_391_495,(0,6,13):C.UVGC_391_496,(0,7,0):C.UVGC_394_505,(0,7,1):C.UVGC_394_506,(0,7,2):C.UVGC_394_507,(0,7,3):C.UVGC_396_522,(0,7,4):C.UVGC_396_523,(0,7,5):C.UVGC_394_509,(0,7,6):C.UVGC_394_510,(0,7,7):C.UVGC_394_511,(0,7,8):C.UVGC_395_518,(0,7,10):C.UVGC_395_519,(0,7,11):C.UVGC_395_520,(0,7,13):C.UVGC_395_521,(0,2,3):C.UVGC_215_5,(0,2,4):C.UVGC_215_6,(0,4,3):C.UVGC_218_11,(0,4,4):C.UVGC_218_12,(0,4,9):C.UVGC_218_13,(0,4,12):C.UVGC_218_14})

V_190 = CTVertex(name = 'V_190',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g, P.g ],
                 color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u], [P.Xd1], [P.Xd2] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd1], [P.Xd2] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu1], [P.Xu2] ], [ [P.Xu2] ] ],
                 couplings = {(2,0,5):C.UVGC_224_22,(2,0,6):C.UVGC_224_23,(2,0,14):C.UVGC_224_24,(0,0,5):C.UVGC_224_22,(0,0,6):C.UVGC_224_23,(0,0,14):C.UVGC_224_24,(4,0,5):C.UVGC_228_33,(4,0,6):C.UVGC_228_34,(4,0,14):C.UVGC_228_35,(3,0,5):C.UVGC_228_33,(3,0,6):C.UVGC_228_34,(3,0,14):C.UVGC_228_35,(8,0,5):C.UVGC_224_23,(8,0,6):C.UVGC_224_22,(8,0,14):C.UVGC_225_25,(7,0,0):C.UVGC_401_566,(7,0,3):C.UVGC_401_567,(7,0,4):C.UVGC_401_568,(7,0,5):C.UVGC_402_578,(7,0,6):C.UVGC_402_579,(7,0,7):C.UVGC_401_571,(7,0,8):C.UVGC_401_572,(7,0,9):C.UVGC_401_573,(7,0,10):C.UVGC_401_574,(7,0,12):C.UVGC_401_575,(7,0,13):C.UVGC_402_580,(7,0,15):C.UVGC_402_581,(6,0,0):C.UVGC_401_566,(6,0,3):C.UVGC_401_567,(6,0,4):C.UVGC_401_568,(6,0,5):C.UVGC_401_569,(6,0,6):C.UVGC_401_570,(6,0,7):C.UVGC_401_571,(6,0,8):C.UVGC_401_572,(6,0,9):C.UVGC_401_573,(6,0,10):C.UVGC_401_574,(6,0,12):C.UVGC_401_575,(6,0,13):C.UVGC_401_576,(6,0,15):C.UVGC_401_577,(5,0,5):C.UVGC_228_33,(5,0,6):C.UVGC_228_34,(5,0,14):C.UVGC_228_35,(1,0,5):C.UVGC_228_33,(1,0,6):C.UVGC_228_34,(1,0,14):C.UVGC_228_35,(11,0,5):C.UVGC_223_19,(11,0,6):C.UVGC_223_20,(11,0,14):C.UVGC_223_21,(10,0,5):C.UVGC_223_19,(10,0,6):C.UVGC_223_20,(10,0,14):C.UVGC_223_21,(9,0,5):C.UVGC_216_7,(9,0,6):C.UVGC_216_8,(2,1,5):C.UVGC_224_22,(2,1,6):C.UVGC_224_23,(2,1,14):C.UVGC_224_24,(0,1,5):C.UVGC_224_22,(0,1,6):C.UVGC_224_23,(0,1,14):C.UVGC_224_24,(6,1,0):C.UVGC_398_536,(6,1,3):C.UVGC_398_537,(6,1,4):C.UVGC_398_538,(6,1,5):C.UVGC_398_539,(6,1,6):C.UVGC_398_540,(6,1,7):C.UVGC_398_541,(6,1,8):C.UVGC_398_542,(6,1,9):C.UVGC_398_543,(6,1,10):C.UVGC_398_544,(6,1,12):C.UVGC_398_545,(6,1,13):C.UVGC_398_546,(6,1,15):C.UVGC_398_547,(4,1,5):C.UVGC_228_33,(4,1,6):C.UVGC_228_34,(4,1,14):C.UVGC_228_35,(3,1,5):C.UVGC_228_33,(3,1,6):C.UVGC_228_34,(3,1,14):C.UVGC_228_35,(8,1,0):C.UVGC_400_554,(8,1,3):C.UVGC_400_555,(8,1,4):C.UVGC_400_556,(8,1,5):C.UVGC_400_557,(8,1,6):C.UVGC_400_558,(8,1,7):C.UVGC_400_559,(8,1,8):C.UVGC_400_560,(8,1,9):C.UVGC_400_561,(8,1,10):C.UVGC_400_562,(8,1,12):C.UVGC_400_563,(8,1,13):C.UVGC_400_564,(8,1,15):C.UVGC_400_565,(7,1,2):C.UVGC_226_26,(7,1,5):C.UVGC_227_30,(7,1,6):C.UVGC_227_31,(7,1,14):C.UVGC_227_32,(5,1,5):C.UVGC_228_33,(5,1,6):C.UVGC_228_34,(5,1,14):C.UVGC_228_35,(1,1,5):C.UVGC_228_33,(1,1,6):C.UVGC_228_34,(1,1,14):C.UVGC_228_35,(11,1,5):C.UVGC_223_19,(11,1,6):C.UVGC_223_20,(11,1,14):C.UVGC_223_21,(10,1,5):C.UVGC_223_19,(10,1,6):C.UVGC_223_20,(10,1,14):C.UVGC_223_21,(9,1,5):C.UVGC_216_7,(9,1,6):C.UVGC_216_8,(2,2,5):C.UVGC_224_22,(2,2,6):C.UVGC_224_23,(2,2,14):C.UVGC_224_24,(0,2,5):C.UVGC_224_22,(0,2,6):C.UVGC_224_23,(0,2,14):C.UVGC_224_24,(4,2,5):C.UVGC_228_33,(4,2,6):C.UVGC_228_34,(4,2,14):C.UVGC_228_35,(3,2,5):C.UVGC_228_33,(3,2,6):C.UVGC_228_34,(3,2,14):C.UVGC_228_35,(8,2,0):C.UVGC_397_524,(8,2,3):C.UVGC_397_525,(8,2,4):C.UVGC_397_526,(8,2,5):C.UVGC_397_527,(8,2,6):C.UVGC_397_528,(8,2,7):C.UVGC_397_529,(8,2,8):C.UVGC_397_530,(8,2,9):C.UVGC_397_531,(8,2,10):C.UVGC_397_532,(8,2,12):C.UVGC_397_533,(8,2,13):C.UVGC_397_534,(8,2,15):C.UVGC_397_535,(6,2,1):C.UVGC_226_26,(6,2,5):C.UVGC_226_27,(6,2,6):C.UVGC_216_7,(6,2,11):C.UVGC_226_28,(6,2,14):C.UVGC_226_29,(7,2,0):C.UVGC_398_536,(7,2,3):C.UVGC_398_537,(7,2,4):C.UVGC_398_538,(7,2,5):C.UVGC_399_548,(7,2,6):C.UVGC_399_549,(7,2,7):C.UVGC_398_541,(7,2,8):C.UVGC_398_542,(7,2,9):C.UVGC_398_543,(7,2,10):C.UVGC_399_550,(7,2,12):C.UVGC_399_551,(7,2,13):C.UVGC_399_552,(7,2,15):C.UVGC_399_553,(5,2,5):C.UVGC_228_33,(5,2,6):C.UVGC_228_34,(5,2,14):C.UVGC_228_35,(1,2,5):C.UVGC_228_33,(1,2,6):C.UVGC_228_34,(1,2,14):C.UVGC_228_35,(11,2,5):C.UVGC_223_19,(11,2,6):C.UVGC_223_20,(11,2,14):C.UVGC_223_21,(10,2,5):C.UVGC_223_19,(10,2,6):C.UVGC_223_20,(10,2,14):C.UVGC_223_21,(9,2,5):C.UVGC_216_7,(9,2,6):C.UVGC_216_8})

V_191 = CTVertex(name = 'V_191',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_366_413,(0,0,2):C.UVGC_366_414,(0,0,1):C.UVGC_366_415,(0,1,0):C.UVGC_367_416,(0,1,2):C.UVGC_367_417,(0,1,1):C.UVGC_367_418})

V_192 = CTVertex(name = 'V_192',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.d, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ], [ [P.c, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_337_362,(0,0,2):C.UVGC_337_363,(0,0,0):C.UVGC_337_364,(0,1,1):C.UVGC_336_359,(0,1,2):C.UVGC_336_360,(0,1,0):C.UVGC_336_361})

V_193 = CTVertex(name = 'V_193',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_383_448,(0,0,2):C.UVGC_383_449,(0,0,1):C.UVGC_383_450,(0,1,0):C.UVGC_384_451,(0,1,2):C.UVGC_384_452,(0,1,1):C.UVGC_384_453})

V_194 = CTVertex(name = 'V_194',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_353_390,(0,0,2):C.UVGC_353_391,(0,0,1):C.UVGC_353_392,(0,1,0):C.UVGC_352_387,(0,1,2):C.UVGC_352_388,(0,1,1):C.UVGC_352_389})

V_195 = CTVertex(name = 'V_195',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.s, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_386_457,(0,0,2):C.UVGC_386_458,(0,0,1):C.UVGC_386_459,(0,1,0):C.UVGC_387_460,(0,1,2):C.UVGC_387_461,(0,1,1):C.UVGC_387_462})

V_196 = CTVertex(name = 'V_196',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_315_330})

V_197 = CTVertex(name = 'V_197',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_333_352})

V_198 = CTVertex(name = 'V_198',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_349_380})

V_199 = CTVertex(name = 'V_199',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_314_329})

V_200 = CTVertex(name = 'V_200',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_332_351})

V_201 = CTVertex(name = 'V_201',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_348_379})

V_202 = CTVertex(name = 'V_202',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.c, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ], [ [P.c, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_331_348,(0,0,2):C.UVGC_331_349,(0,0,0):C.UVGC_331_350,(0,1,1):C.UVGC_334_353,(0,1,2):C.UVGC_334_354,(0,1,0):C.UVGC_334_355})

V_203 = CTVertex(name = 'V_203',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_347_376,(0,0,2):C.UVGC_347_377,(0,0,1):C.UVGC_347_378,(0,1,0):C.UVGC_350_381,(0,1,2):C.UVGC_350_382,(0,1,1):C.UVGC_350_383})

V_204 = CTVertex(name = 'V_204',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_364_407,(0,0,2):C.UVGC_364_408,(0,0,1):C.UVGC_364_409,(0,1,0):C.UVGC_361_402,(0,1,2):C.UVGC_361_403,(0,1,1):C.UVGC_361_404})

V_205 = CTVertex(name = 'V_205',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_380_439,(0,0,2):C.UVGC_380_440,(0,0,1):C.UVGC_380_441,(0,1,0):C.UVGC_376_431,(0,1,2):C.UVGC_376_432,(0,1,1):C.UVGC_376_433})

V_206 = CTVertex(name = 'V_206',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.u, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3, L.FFS4 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_381_442,(0,0,2):C.UVGC_381_443,(0,0,1):C.UVGC_381_444,(0,1,0):C.UVGC_377_434,(0,1,2):C.UVGC_377_435,(0,1,1):C.UVGC_377_436})

V_207 = CTVertex(name = 'V_207',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_322_337})

V_208 = CTVertex(name = 'V_208',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_362_405})

V_209 = CTVertex(name = 'V_209',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_378_437})

V_210 = CTVertex(name = 'V_210',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_323_338})

V_211 = CTVertex(name = 'V_211',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_363_406})

V_212 = CTVertex(name = 'V_212',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_379_438})

V_213 = CTVertex(name = 'V_213',
                 type = 'UV',
                 particles = [ P.a, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_240_48})

V_214 = CTVertex(name = 'V_214',
                 type = 'UV',
                 particles = [ P.g, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd1] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_242_50,(0,0,1):C.UVGC_242_51,(0,0,2):C.UVGC_242_52,(0,0,3):C.UVGC_242_53,(0,0,4):C.UVGC_242_54,(0,0,6):C.UVGC_242_55,(0,0,7):C.UVGC_242_56,(0,0,8):C.UVGC_242_57,(0,0,9):C.UVGC_242_58,(0,0,10):C.UVGC_242_59,(0,0,11):C.UVGC_242_60,(0,0,12):C.UVGC_242_61,(0,0,5):C.UVGC_242_62})

V_215 = CTVertex(name = 'V_215',
                 type = 'UV',
                 particles = [ P.a, P.a, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_241_49})

V_216 = CTVertex(name = 'V_216',
                 type = 'UV',
                 particles = [ P.a, P.g, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd1] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_243_63,(0,0,1):C.UVGC_243_64,(0,0,2):C.UVGC_243_65,(0,0,3):C.UVGC_243_66,(0,0,4):C.UVGC_243_67,(0,0,6):C.UVGC_243_68,(0,0,7):C.UVGC_243_69,(0,0,8):C.UVGC_243_70,(0,0,9):C.UVGC_243_71,(0,0,10):C.UVGC_243_72,(0,0,11):C.UVGC_243_73,(0,0,12):C.UVGC_243_74,(0,0,5):C.UVGC_243_75})

V_217 = CTVertex(name = 'V_217',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_245_89})

V_218 = CTVertex(name = 'V_218',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_245_89})

V_219 = CTVertex(name = 'V_219',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_245_89})

V_220 = CTVertex(name = 'V_220',
                 type = 'UV',
                 particles = [ P.H, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_251_107})

V_221 = CTVertex(name = 'V_221',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd1] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(2,0,0):C.UVGC_244_76,(2,0,1):C.UVGC_244_77,(2,0,2):C.UVGC_244_78,(2,0,3):C.UVGC_244_79,(2,0,4):C.UVGC_244_80,(2,0,6):C.UVGC_244_81,(2,0,7):C.UVGC_244_82,(2,0,8):C.UVGC_244_83,(2,0,9):C.UVGC_244_84,(2,0,10):C.UVGC_244_85,(2,0,11):C.UVGC_244_86,(2,0,12):C.UVGC_244_87,(2,0,5):C.UVGC_244_88,(1,0,0):C.UVGC_244_76,(1,0,1):C.UVGC_244_77,(1,0,2):C.UVGC_244_78,(1,0,3):C.UVGC_244_79,(1,0,4):C.UVGC_244_80,(1,0,6):C.UVGC_244_81,(1,0,7):C.UVGC_244_82,(1,0,8):C.UVGC_244_83,(1,0,9):C.UVGC_244_84,(1,0,10):C.UVGC_244_85,(1,0,11):C.UVGC_244_86,(1,0,12):C.UVGC_244_87,(1,0,5):C.UVGC_244_88,(0,0,3):C.UVGC_238_45,(0,0,5):C.UVGC_238_46})

V_222 = CTVertex(name = 'V_222',
                 type = 'UV',
                 particles = [ P.g, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_242_50,(0,0,1):C.UVGC_242_51,(0,0,2):C.UVGC_242_52,(0,0,3):C.UVGC_242_53,(0,0,4):C.UVGC_242_54,(0,0,6):C.UVGC_242_55,(0,0,7):C.UVGC_242_56,(0,0,8):C.UVGC_242_57,(0,0,9):C.UVGC_242_58,(0,0,10):C.UVGC_242_59,(0,0,11):C.UVGC_242_60,(0,0,12):C.UVGC_242_61,(0,0,5):C.UVGC_256_111})

V_223 = CTVertex(name = 'V_223',
                 type = 'UV',
                 particles = [ P.a, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_254_109})

V_224 = CTVertex(name = 'V_224',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS2, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,1,0):C.UVGC_432_734,(0,1,2):C.UVGC_432_735,(0,1,3):C.UVGC_432_736,(0,1,1):C.UVGC_432_737,(0,0,0):C.UVGC_213_3,(0,2,2):C.UVGC_268_136})

V_225 = CTVertex(name = 'V_225',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS2, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,1,0):C.UVGC_429_710,(0,1,2):C.UVGC_429_711,(0,1,3):C.UVGC_429_712,(0,1,1):C.UVGC_429_713,(0,0,0):C.UVGC_211_1,(0,2,3):C.UVGC_272_139})

V_226 = CTVertex(name = 'V_226',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(2,0,0):C.UVGC_244_76,(2,0,1):C.UVGC_244_77,(2,0,2):C.UVGC_244_78,(2,0,3):C.UVGC_244_79,(2,0,4):C.UVGC_244_80,(2,0,6):C.UVGC_244_81,(2,0,7):C.UVGC_244_82,(2,0,8):C.UVGC_244_83,(2,0,9):C.UVGC_244_84,(2,0,10):C.UVGC_244_85,(2,0,11):C.UVGC_244_86,(2,0,12):C.UVGC_244_87,(2,0,5):C.UVGC_258_113,(1,0,0):C.UVGC_244_76,(1,0,1):C.UVGC_244_77,(1,0,2):C.UVGC_244_78,(1,0,3):C.UVGC_244_79,(1,0,4):C.UVGC_244_80,(1,0,6):C.UVGC_244_81,(1,0,7):C.UVGC_244_82,(1,0,8):C.UVGC_244_83,(1,0,9):C.UVGC_244_84,(1,0,10):C.UVGC_244_85,(1,0,11):C.UVGC_244_86,(1,0,12):C.UVGC_244_87,(1,0,5):C.UVGC_258_113,(0,0,3):C.UVGC_238_45,(0,0,5):C.UVGC_238_46})

V_227 = CTVertex(name = 'V_227',
                 type = 'UV',
                 particles = [ P.a, P.g, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_243_63,(0,0,1):C.UVGC_243_64,(0,0,2):C.UVGC_243_65,(0,0,3):C.UVGC_243_66,(0,0,4):C.UVGC_243_67,(0,0,6):C.UVGC_243_68,(0,0,7):C.UVGC_243_69,(0,0,8):C.UVGC_243_70,(0,0,9):C.UVGC_243_71,(0,0,10):C.UVGC_243_72,(0,0,11):C.UVGC_243_73,(0,0,12):C.UVGC_243_74,(0,0,5):C.UVGC_257_112})

V_228 = CTVertex(name = 'V_228',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS2, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,1,0):C.UVGC_433_738,(0,1,2):C.UVGC_433_739,(0,1,3):C.UVGC_433_740,(0,1,1):C.UVGC_433_741,(0,0,0):C.UVGC_214_4,(0,2,2):C.UVGC_267_135})

V_229 = CTVertex(name = 'V_229',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS2, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,1,0):C.UVGC_428_706,(0,1,2):C.UVGC_428_707,(0,1,3):C.UVGC_428_708,(0,1,1):C.UVGC_428_709,(0,0,0):C.UVGC_212_2,(0,2,3):C.UVGC_271_138})

V_230 = CTVertex(name = 'V_230',
                 type = 'UV',
                 particles = [ P.a, P.a, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_255_110})

V_231 = CTVertex(name = 'V_231',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_284_153,(0,0,3):C.UVGC_284_154,(0,0,4):C.UVGC_284_155,(0,0,1):C.UVGC_284_156,(0,0,2):C.UVGC_284_157})

V_232 = CTVertex(name = 'V_232',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_259_114})

V_233 = CTVertex(name = 'V_233',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_259_114})

V_234 = CTVertex(name = 'V_234',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_259_114})

V_235 = CTVertex(name = 'V_235',
                 type = 'UV',
                 particles = [ P.H, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_265_132})

V_236 = CTVertex(name = 'V_236',
                 type = 'UV',
                 particles = [ P.a, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_411_617,(0,0,1):C.UVGC_411_618,(0,0,2):C.UVGC_411_619})

V_237 = CTVertex(name = 'V_237',
                 type = 'UV',
                 particles = [ P.G__plus__, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_405_590,(0,0,2):C.UVGC_405_591,(0,0,3):C.UVGC_405_592,(0,0,1):C.UVGC_405_593})

V_238 = CTVertex(name = 'V_238',
                 type = 'UV',
                 particles = [ P.g, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_415_627,(0,0,1):C.UVGC_415_628,(0,0,2):C.UVGC_415_629,(0,0,3):C.UVGC_415_630,(0,0,4):C.UVGC_415_631,(0,0,8):C.UVGC_415_632,(0,0,9):C.UVGC_415_633,(0,0,10):C.UVGC_415_634,(0,0,11):C.UVGC_415_635,(0,0,12):C.UVGC_415_636,(0,0,13):C.UVGC_415_637,(0,0,14):C.UVGC_415_638,(0,0,5):C.UVGC_415_639,(0,0,6):C.UVGC_415_640,(0,0,7):C.UVGC_415_641})

V_239 = CTVertex(name = 'V_239',
                 type = 'UV',
                 particles = [ P.g, P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_435_746,(0,0,1):C.UVGC_435_747,(0,0,2):C.UVGC_435_748,(0,0,3):C.UVGC_435_749,(0,0,4):C.UVGC_435_750,(0,0,9):C.UVGC_435_751,(0,0,10):C.UVGC_435_752,(0,0,11):C.UVGC_435_753,(0,0,12):C.UVGC_435_754,(0,0,13):C.UVGC_435_755,(0,0,14):C.UVGC_435_756,(0,0,15):C.UVGC_435_757,(0,0,5):C.UVGC_435_758,(0,0,7):C.UVGC_435_759,(0,0,8):C.UVGC_435_760,(0,0,6):C.UVGC_435_761})

V_240 = CTVertex(name = 'V_240',
                 type = 'UV',
                 particles = [ P.a, P.W__plus__, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_434_742,(0,0,2):C.UVGC_434_743,(0,0,3):C.UVGC_434_744,(0,0,1):C.UVGC_434_745})

V_241 = CTVertex(name = 'V_241',
                 type = 'UV',
                 particles = [ P.a, P.a, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_413_622,(0,0,1):C.UVGC_413_623,(0,0,2):C.UVGC_413_624})

V_242 = CTVertex(name = 'V_242',
                 type = 'UV',
                 particles = [ P.a, P.g, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_417_644,(0,0,1):C.UVGC_417_645,(0,0,2):C.UVGC_417_646,(0,0,3):C.UVGC_417_647,(0,0,4):C.UVGC_417_648,(0,0,8):C.UVGC_417_649,(0,0,9):C.UVGC_417_650,(0,0,10):C.UVGC_417_651,(0,0,11):C.UVGC_417_652,(0,0,12):C.UVGC_417_653,(0,0,13):C.UVGC_417_654,(0,0,14):C.UVGC_417_655,(0,0,5):C.UVGC_417_656,(0,0,6):C.UVGC_417_657,(0,0,7):C.UVGC_417_658})

V_243 = CTVertex(name = 'V_243',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_421_678,(0,0,1):C.UVGC_421_679,(0,0,2):C.UVGC_421_680})

V_244 = CTVertex(name = 'V_244',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_421_678,(0,0,1):C.UVGC_421_679,(0,0,2):C.UVGC_421_680})

V_245 = CTVertex(name = 'V_245',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_421_678,(0,0,1):C.UVGC_421_679,(0,0,2):C.UVGC_421_680})

V_246 = CTVertex(name = 'V_246',
                 type = 'UV',
                 particles = [ P.H, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_454_857,(0,0,1):C.UVGC_454_858,(0,0,2):C.UVGC_454_859})

V_247 = CTVertex(name = 'V_247',
                 type = 'UV',
                 particles = [ P.G__minus__, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_406_594,(0,0,2):C.UVGC_406_595,(0,0,3):C.UVGC_406_596,(0,0,1):C.UVGC_406_597})

V_248 = CTVertex(name = 'V_248',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(2,0,0):C.UVGC_419_661,(2,0,1):C.UVGC_419_662,(2,0,2):C.UVGC_419_663,(2,0,3):C.UVGC_419_664,(2,0,4):C.UVGC_419_665,(2,0,8):C.UVGC_419_666,(2,0,9):C.UVGC_419_667,(2,0,10):C.UVGC_419_668,(2,0,11):C.UVGC_419_669,(2,0,12):C.UVGC_419_670,(2,0,13):C.UVGC_419_671,(2,0,14):C.UVGC_419_672,(2,0,5):C.UVGC_419_673,(2,0,6):C.UVGC_419_674,(2,0,7):C.UVGC_419_675,(1,0,0):C.UVGC_419_661,(1,0,1):C.UVGC_419_662,(1,0,2):C.UVGC_419_663,(1,0,3):C.UVGC_419_664,(1,0,4):C.UVGC_419_665,(1,0,8):C.UVGC_419_666,(1,0,9):C.UVGC_419_667,(1,0,10):C.UVGC_419_668,(1,0,11):C.UVGC_419_669,(1,0,12):C.UVGC_419_670,(1,0,13):C.UVGC_419_671,(1,0,14):C.UVGC_419_672,(1,0,5):C.UVGC_419_673,(1,0,6):C.UVGC_419_674,(1,0,7):C.UVGC_419_675,(0,0,3):C.UVGC_266_133,(0,0,6):C.UVGC_266_134})

V_249 = CTVertex(name = 'V_249',
                 type = 'UV',
                 particles = [ P.g, P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_435_746,(0,0,1):C.UVGC_435_747,(0,0,2):C.UVGC_435_748,(0,0,3):C.UVGC_435_749,(0,0,4):C.UVGC_435_750,(0,0,9):C.UVGC_435_751,(0,0,10):C.UVGC_435_752,(0,0,11):C.UVGC_435_753,(0,0,12):C.UVGC_435_754,(0,0,13):C.UVGC_435_755,(0,0,14):C.UVGC_435_756,(0,0,15):C.UVGC_435_757,(0,0,5):C.UVGC_435_758,(0,0,7):C.UVGC_435_759,(0,0,8):C.UVGC_435_760,(0,0,6):C.UVGC_435_761})

V_250 = CTVertex(name = 'V_250',
                 type = 'UV',
                 particles = [ P.a, P.W__minus__, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_434_742,(0,0,2):C.UVGC_434_743,(0,0,3):C.UVGC_434_744,(0,0,1):C.UVGC_434_745})

V_251 = CTVertex(name = 'V_251',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_427_702,(0,0,2):C.UVGC_427_703,(0,0,3):C.UVGC_427_704,(0,0,1):C.UVGC_427_705})

V_252 = CTVertex(name = 'V_252',
                 type = 'UV',
                 particles = [ P.a, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_411_617,(0,0,1):C.UVGC_412_620,(0,0,2):C.UVGC_412_621})

V_253 = CTVertex(name = 'V_253',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_254 = CTVertex(name = 'V_254',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_255 = CTVertex(name = 'V_255',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_256 = CTVertex(name = 'V_256',
                 type = 'UV',
                 particles = [ P.H, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_453_853,(0,0,1):C.UVGC_453_854,(0,0,3):C.UVGC_453_855,(0,0,2):C.UVGC_453_856})

V_257 = CTVertex(name = 'V_257',
                 type = 'UV',
                 particles = [ P.G0, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_423_684,(0,0,1):C.UVGC_423_685,(0,0,3):C.UVGC_423_686,(0,0,2):C.UVGC_423_687})

V_258 = CTVertex(name = 'V_258',
                 type = 'UV',
                 particles = [ P.G__plus__, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_408_602,(0,0,2):C.UVGC_408_603,(0,0,3):C.UVGC_408_604,(0,0,1):C.UVGC_408_605})

V_259 = CTVertex(name = 'V_259',
                 type = 'UV',
                 particles = [ P.g, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_415_627,(0,0,1):C.UVGC_415_628,(0,0,2):C.UVGC_415_629,(0,0,3):C.UVGC_415_630,(0,0,4):C.UVGC_415_631,(0,0,8):C.UVGC_415_632,(0,0,9):C.UVGC_415_633,(0,0,10):C.UVGC_415_634,(0,0,11):C.UVGC_415_635,(0,0,12):C.UVGC_415_636,(0,0,13):C.UVGC_415_637,(0,0,14):C.UVGC_415_638,(0,0,5):C.UVGC_415_639,(0,0,6):C.UVGC_416_642,(0,0,7):C.UVGC_416_643})

V_260 = CTVertex(name = 'V_260',
                 type = 'UV',
                 particles = [ P.g, P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_431_718,(0,0,1):C.UVGC_431_719,(0,0,2):C.UVGC_431_720,(0,0,3):C.UVGC_431_721,(0,0,4):C.UVGC_431_722,(0,0,9):C.UVGC_431_723,(0,0,10):C.UVGC_431_724,(0,0,11):C.UVGC_431_725,(0,0,12):C.UVGC_431_726,(0,0,13):C.UVGC_431_727,(0,0,14):C.UVGC_431_728,(0,0,15):C.UVGC_431_729,(0,0,5):C.UVGC_431_730,(0,0,7):C.UVGC_431_731,(0,0,8):C.UVGC_431_732,(0,0,6):C.UVGC_431_733})

V_261 = CTVertex(name = 'V_261',
                 type = 'UV',
                 particles = [ P.a, P.W__plus__, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_430_714,(0,0,2):C.UVGC_430_715,(0,0,3):C.UVGC_430_716,(0,0,1):C.UVGC_430_717})

V_262 = CTVertex(name = 'V_262',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1], [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_426_696,(0,0,3):C.UVGC_426_697,(0,0,5):C.UVGC_426_698,(0,0,1):C.UVGC_426_699,(0,0,4):C.UVGC_426_700,(0,0,2):C.UVGC_426_701})

V_263 = CTVertex(name = 'V_263',
                 type = 'UV',
                 particles = [ P.a, P.a, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_413_622,(0,0,1):C.UVGC_414_625,(0,0,2):C.UVGC_414_626})

V_264 = CTVertex(name = 'V_264',
                 type = 'UV',
                 particles = [ P.a, P.g, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_417_644,(0,0,1):C.UVGC_417_645,(0,0,2):C.UVGC_417_646,(0,0,3):C.UVGC_417_647,(0,0,4):C.UVGC_417_648,(0,0,8):C.UVGC_417_649,(0,0,9):C.UVGC_417_650,(0,0,10):C.UVGC_417_651,(0,0,11):C.UVGC_417_652,(0,0,12):C.UVGC_417_653,(0,0,13):C.UVGC_417_654,(0,0,14):C.UVGC_417_655,(0,0,5):C.UVGC_417_656,(0,0,6):C.UVGC_418_659,(0,0,7):C.UVGC_418_660})

V_265 = CTVertex(name = 'V_265',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_266 = CTVertex(name = 'V_266',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_267 = CTVertex(name = 'V_267',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_407_598,(0,0,1):C.UVGC_407_599,(0,0,3):C.UVGC_407_600,(0,0,2):C.UVGC_407_601})

V_268 = CTVertex(name = 'V_268',
                 type = 'UV',
                 particles = [ P.H, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_453_853,(0,0,1):C.UVGC_453_854,(0,0,3):C.UVGC_453_855,(0,0,2):C.UVGC_453_856})

V_269 = CTVertex(name = 'V_269',
                 type = 'UV',
                 particles = [ P.G0, P.G0, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_422_681,(0,0,1):C.UVGC_422_682,(0,0,2):C.UVGC_422_683})

V_270 = CTVertex(name = 'V_270',
                 type = 'UV',
                 particles = [ P.G__minus__, P.G__plus__, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_422_681,(0,0,1):C.UVGC_422_682,(0,0,2):C.UVGC_422_683})

V_271 = CTVertex(name = 'V_271',
                 type = 'UV',
                 particles = [ P.H, P.H, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_422_681,(0,0,1):C.UVGC_422_682,(0,0,2):C.UVGC_422_683})

V_272 = CTVertex(name = 'V_272',
                 type = 'UV',
                 particles = [ P.H, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_455_860,(0,0,1):C.UVGC_455_861,(0,0,2):C.UVGC_455_862})

V_273 = CTVertex(name = 'V_273',
                 type = 'UV',
                 particles = [ P.G__minus__, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_409_606,(0,0,2):C.UVGC_409_607,(0,0,3):C.UVGC_409_608,(0,0,1):C.UVGC_409_609})

V_274 = CTVertex(name = 'V_274',
                 type = 'UV',
                 particles = [ P.G0, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_424_688,(0,0,1):C.UVGC_424_689,(0,0,3):C.UVGC_424_690,(0,0,2):C.UVGC_424_691})

V_275 = CTVertex(name = 'V_275',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(2,0,0):C.UVGC_419_661,(2,0,1):C.UVGC_419_662,(2,0,2):C.UVGC_419_663,(2,0,3):C.UVGC_419_664,(2,0,4):C.UVGC_419_665,(2,0,8):C.UVGC_419_666,(2,0,9):C.UVGC_419_667,(2,0,10):C.UVGC_419_668,(2,0,11):C.UVGC_419_669,(2,0,12):C.UVGC_419_670,(2,0,13):C.UVGC_419_671,(2,0,14):C.UVGC_419_672,(2,0,5):C.UVGC_419_673,(2,0,6):C.UVGC_420_676,(2,0,7):C.UVGC_420_677,(1,0,0):C.UVGC_419_661,(1,0,1):C.UVGC_419_662,(1,0,2):C.UVGC_419_663,(1,0,3):C.UVGC_419_664,(1,0,4):C.UVGC_419_665,(1,0,8):C.UVGC_419_666,(1,0,9):C.UVGC_419_667,(1,0,10):C.UVGC_419_668,(1,0,11):C.UVGC_419_669,(1,0,12):C.UVGC_419_670,(1,0,13):C.UVGC_419_671,(1,0,14):C.UVGC_419_672,(1,0,5):C.UVGC_419_673,(1,0,6):C.UVGC_420_676,(1,0,7):C.UVGC_420_677,(0,0,3):C.UVGC_266_133,(0,0,7):C.UVGC_266_134})

V_276 = CTVertex(name = 'V_276',
                 type = 'UV',
                 particles = [ P.g, P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_431_718,(0,0,1):C.UVGC_431_719,(0,0,2):C.UVGC_431_720,(0,0,3):C.UVGC_431_721,(0,0,4):C.UVGC_431_722,(0,0,9):C.UVGC_431_723,(0,0,10):C.UVGC_431_724,(0,0,11):C.UVGC_431_725,(0,0,12):C.UVGC_431_726,(0,0,13):C.UVGC_431_727,(0,0,14):C.UVGC_431_728,(0,0,15):C.UVGC_431_729,(0,0,5):C.UVGC_431_730,(0,0,7):C.UVGC_431_731,(0,0,8):C.UVGC_431_732,(0,0,6):C.UVGC_431_733})

V_277 = CTVertex(name = 'V_277',
                 type = 'UV',
                 particles = [ P.a, P.W__minus__, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_430_714,(0,0,2):C.UVGC_430_715,(0,0,3):C.UVGC_430_716,(0,0,1):C.UVGC_430_717})

V_278 = CTVertex(name = 'V_278',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1], [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_426_696,(0,0,3):C.UVGC_426_697,(0,0,5):C.UVGC_426_698,(0,0,1):C.UVGC_426_699,(0,0,4):C.UVGC_426_700,(0,0,2):C.UVGC_426_701})

V_279 = CTVertex(name = 'V_279',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_425_692,(0,0,2):C.UVGC_425_693,(0,0,3):C.UVGC_425_694,(0,0,1):C.UVGC_425_695})

V_280 = CTVertex(name = 'V_280',
                 type = 'UV',
                 particles = [ P.Z, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_247_91,(0,1,0):C.UVGC_246_90})

V_281 = CTVertex(name = 'V_281',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_248_92})

V_282 = CTVertex(name = 'V_282',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd1] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_249_93,(0,0,1):C.UVGC_249_94,(0,0,2):C.UVGC_249_95,(0,0,3):C.UVGC_249_96,(0,0,4):C.UVGC_249_97,(0,0,6):C.UVGC_249_98,(0,0,7):C.UVGC_249_99,(0,0,8):C.UVGC_249_100,(0,0,9):C.UVGC_249_101,(0,0,10):C.UVGC_249_102,(0,0,11):C.UVGC_249_103,(0,0,12):C.UVGC_249_104,(0,0,5):C.UVGC_249_105})

V_283 = CTVertex(name = 'V_283',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_250_106})

V_284 = CTVertex(name = 'V_284',
                 type = 'UV',
                 particles = [ P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_443_797,(0,0,1):C.UVGC_443_798,(0,0,2):C.UVGC_443_799,(0,1,0):C.UVGC_442_794,(0,1,1):C.UVGC_442_795,(0,1,2):C.UVGC_442_796})

V_285 = CTVertex(name = 'V_285',
                 type = 'UV',
                 particles = [ P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_436_762,(0,0,1):C.UVGC_436_763,(0,0,3):C.UVGC_436_764,(0,0,2):C.UVGC_436_765,(0,1,0):C.UVGC_438_768,(0,1,1):C.UVGC_439_772,(0,1,3):C.UVGC_439_773,(0,1,2):C.UVGC_438_771})

V_286 = CTVertex(name = 'V_286',
                 type = 'UV',
                 particles = [ P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_438_768,(0,0,1):C.UVGC_438_769,(0,0,3):C.UVGC_438_770,(0,0,2):C.UVGC_438_771,(0,1,0):C.UVGC_436_762,(0,1,1):C.UVGC_437_766,(0,1,3):C.UVGC_437_767,(0,1,2):C.UVGC_436_765})

V_287 = CTVertex(name = 'V_287',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_446_806,(0,0,1):C.UVGC_446_807,(0,0,2):C.UVGC_446_808})

V_288 = CTVertex(name = 'V_288',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_448_812,(0,0,1):C.UVGC_448_813,(0,0,2):C.UVGC_448_814,(0,0,3):C.UVGC_448_815,(0,0,4):C.UVGC_448_816,(0,0,8):C.UVGC_448_817,(0,0,9):C.UVGC_448_818,(0,0,10):C.UVGC_448_819,(0,0,11):C.UVGC_448_820,(0,0,12):C.UVGC_448_821,(0,0,13):C.UVGC_448_822,(0,0,14):C.UVGC_448_823,(0,0,5):C.UVGC_448_824,(0,0,6):C.UVGC_448_825,(0,0,7):C.UVGC_448_826})

V_289 = CTVertex(name = 'V_289',
                 type = 'UV',
                 particles = [ P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_445_803,(0,0,1):C.UVGC_445_804,(0,0,2):C.UVGC_445_805,(0,1,0):C.UVGC_444_800,(0,1,1):C.UVGC_444_801,(0,1,2):C.UVGC_444_802})

V_290 = CTVertex(name = 'V_290',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_440_774,(0,0,1):C.UVGC_440_775,(0,0,3):C.UVGC_440_776,(0,0,2):C.UVGC_440_777})

V_291 = CTVertex(name = 'V_291',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_441_778,(0,0,1):C.UVGC_441_779,(0,0,2):C.UVGC_441_780,(0,0,3):C.UVGC_441_781,(0,0,4):C.UVGC_441_782,(0,0,9):C.UVGC_441_783,(0,0,10):C.UVGC_441_784,(0,0,11):C.UVGC_441_785,(0,0,12):C.UVGC_441_786,(0,0,13):C.UVGC_441_787,(0,0,14):C.UVGC_441_788,(0,0,15):C.UVGC_441_789,(0,0,5):C.UVGC_441_790,(0,0,6):C.UVGC_441_791,(0,0,8):C.UVGC_441_792,(0,0,7):C.UVGC_441_793})

V_292 = CTVertex(name = 'V_292',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_440_774,(0,0,1):C.UVGC_440_775,(0,0,3):C.UVGC_440_776,(0,0,2):C.UVGC_440_777})

V_293 = CTVertex(name = 'V_293',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_441_778,(0,0,1):C.UVGC_441_779,(0,0,2):C.UVGC_441_780,(0,0,3):C.UVGC_441_781,(0,0,4):C.UVGC_441_782,(0,0,9):C.UVGC_441_783,(0,0,10):C.UVGC_441_784,(0,0,11):C.UVGC_441_785,(0,0,12):C.UVGC_441_786,(0,0,13):C.UVGC_441_787,(0,0,14):C.UVGC_441_788,(0,0,15):C.UVGC_441_789,(0,0,5):C.UVGC_441_790,(0,0,6):C.UVGC_441_791,(0,0,8):C.UVGC_441_792,(0,0,7):C.UVGC_441_793})

V_294 = CTVertex(name = 'V_294',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_447_809,(0,0,1):C.UVGC_447_810,(0,0,2):C.UVGC_447_811})

V_295 = CTVertex(name = 'V_295',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_449_827,(0,0,1):C.UVGC_449_828,(0,0,2):C.UVGC_449_829,(0,0,3):C.UVGC_449_830,(0,0,4):C.UVGC_449_831,(0,0,8):C.UVGC_449_832,(0,0,9):C.UVGC_449_833,(0,0,10):C.UVGC_449_834,(0,0,11):C.UVGC_449_835,(0,0,12):C.UVGC_449_836,(0,0,13):C.UVGC_449_837,(0,0,14):C.UVGC_449_838,(0,0,5):C.UVGC_449_839,(0,0,6):C.UVGC_449_840,(0,0,7):C.UVGC_449_841})

V_296 = CTVertex(name = 'V_296',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_451_846,(0,0,1):C.UVGC_451_847,(0,0,3):C.UVGC_451_848,(0,0,2):C.UVGC_451_849})

V_297 = CTVertex(name = 'V_297',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_450_842,(0,0,1):C.UVGC_450_843,(0,0,3):C.UVGC_450_844,(0,0,2):C.UVGC_450_845})

V_298 = CTVertex(name = 'V_298',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_450_842,(0,0,1):C.UVGC_450_843,(0,0,3):C.UVGC_450_844,(0,0,2):C.UVGC_450_845})

V_299 = CTVertex(name = 'V_299',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_452_850,(0,0,1):C.UVGC_452_851,(0,0,3):C.UVGC_452_852,(0,0,2):C.UVGC_451_849})

V_300 = CTVertex(name = 'V_300',
                 type = 'UV',
                 particles = [ P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_260_115,(0,1,0):C.UVGC_261_116})

V_301 = CTVertex(name = 'V_301',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.Xd2] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_263_118,(0,0,1):C.UVGC_263_119,(0,0,2):C.UVGC_263_120,(0,0,3):C.UVGC_263_121,(0,0,4):C.UVGC_263_122,(0,0,6):C.UVGC_263_123,(0,0,7):C.UVGC_263_124,(0,0,8):C.UVGC_263_125,(0,0,9):C.UVGC_263_126,(0,0,10):C.UVGC_263_127,(0,0,11):C.UVGC_263_128,(0,0,12):C.UVGC_263_129,(0,0,5):C.UVGC_263_130})

V_302 = CTVertex(name = 'V_302',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_262_117})

V_303 = CTVertex(name = 'V_303',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Z, P.Xd2, P.Xu1__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_410_610,(0,0,4):C.UVGC_410_611,(0,0,6):C.UVGC_410_612,(0,0,1):C.UVGC_410_613,(0,0,3):C.UVGC_410_614,(0,0,5):C.UVGC_410_615,(0,0,2):C.UVGC_410_616})

V_304 = CTVertex(name = 'V_304',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Z, P.Xd2__tilde__, P.Xu1 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_410_610,(0,0,4):C.UVGC_410_611,(0,0,6):C.UVGC_410_612,(0,0,1):C.UVGC_410_613,(0,0,3):C.UVGC_410_614,(0,0,5):C.UVGC_410_615,(0,0,2):C.UVGC_410_616})

V_305 = CTVertex(name = 'V_305',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Z, P.Xd2, P.Xu2__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_404_583,(0,0,4):C.UVGC_404_584,(0,0,6):C.UVGC_404_585,(0,0,1):C.UVGC_404_586,(0,0,3):C.UVGC_404_587,(0,0,5):C.UVGC_404_588,(0,0,2):C.UVGC_404_589})

V_306 = CTVertex(name = 'V_306',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Z, P.Xd2__tilde__, P.Xu2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_404_583,(0,0,4):C.UVGC_404_584,(0,0,6):C.UVGC_404_585,(0,0,1):C.UVGC_404_586,(0,0,3):C.UVGC_404_587,(0,0,5):C.UVGC_404_588,(0,0,2):C.UVGC_404_589})

V_307 = CTVertex(name = 'V_307',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_264_131})

V_308 = CTVertex(name = 'V_308',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_234_44,(0,1,0):C.UVGC_317_332,(0,2,0):C.UVGC_317_332})

V_309 = CTVertex(name = 'V_309',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_234_44,(0,1,0):C.UVGC_355_394,(0,2,0):C.UVGC_355_394})

V_310 = CTVertex(name = 'V_310',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_234_44,(0,1,0):C.UVGC_369_420,(0,2,0):C.UVGC_369_420})

V_311 = CTVertex(name = 'V_311',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_232_42,(0,1,0):C.UVGC_309_312,(0,2,0):C.UVGC_309_312})

V_312 = CTVertex(name = 'V_312',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_232_42,(0,1,0):C.UVGC_325_340,(0,2,0):C.UVGC_325_340})

V_313 = CTVertex(name = 'V_313',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_232_42,(0,1,0):C.UVGC_341_368,(0,2,0):C.UVGC_341_368})

V_314 = CTVertex(name = 'V_314',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.c, P.g] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,2):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,1):C.UVGC_310_314,(0,1,3):C.UVGC_310_315,(0,1,4):C.UVGC_310_316,(0,1,5):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,2):C.UVGC_318_333,(0,2,0):C.UVGC_310_313,(0,2,1):C.UVGC_310_314,(0,2,3):C.UVGC_310_315,(0,2,4):C.UVGC_310_316,(0,2,5):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,2):C.UVGC_318_333})

V_315 = CTVertex(name = 'V_315',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.t] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,5):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,1):C.UVGC_310_314,(0,1,2):C.UVGC_310_315,(0,1,3):C.UVGC_310_316,(0,1,4):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,5):C.UVGC_356_395,(0,2,0):C.UVGC_310_313,(0,2,1):C.UVGC_310_314,(0,2,2):C.UVGC_310_315,(0,2,3):C.UVGC_310_316,(0,2,4):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,5):C.UVGC_356_395})

V_316 = CTVertex(name = 'V_316',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.u] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,5):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,1):C.UVGC_310_314,(0,1,2):C.UVGC_310_315,(0,1,3):C.UVGC_310_316,(0,1,4):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,5):C.UVGC_370_421,(0,2,0):C.UVGC_310_313,(0,2,1):C.UVGC_310_314,(0,2,2):C.UVGC_310_315,(0,2,3):C.UVGC_310_316,(0,2,4):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,5):C.UVGC_370_421})

V_317 = CTVertex(name = 'V_317',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.b, P.g] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,1):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,2):C.UVGC_310_314,(0,1,3):C.UVGC_310_315,(0,1,4):C.UVGC_310_316,(0,1,5):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,1):C.UVGC_310_325,(0,2,0):C.UVGC_310_313,(0,2,2):C.UVGC_310_314,(0,2,3):C.UVGC_310_315,(0,2,4):C.UVGC_310_316,(0,2,5):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,1):C.UVGC_310_325})

V_318 = CTVertex(name = 'V_318',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.d, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,3):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,1):C.UVGC_310_314,(0,1,2):C.UVGC_310_315,(0,1,4):C.UVGC_310_316,(0,1,5):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,3):C.UVGC_326_341,(0,2,0):C.UVGC_310_313,(0,2,1):C.UVGC_310_314,(0,2,2):C.UVGC_310_315,(0,2,4):C.UVGC_310_316,(0,2,5):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,3):C.UVGC_326_341})

V_319 = CTVertex(name = 'V_319',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.s] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,5):C.UVGC_233_43,(0,1,0):C.UVGC_310_313,(0,1,1):C.UVGC_310_314,(0,1,2):C.UVGC_310_315,(0,1,3):C.UVGC_310_316,(0,1,4):C.UVGC_310_317,(0,1,6):C.UVGC_310_318,(0,1,7):C.UVGC_310_319,(0,1,8):C.UVGC_310_320,(0,1,9):C.UVGC_310_321,(0,1,10):C.UVGC_310_322,(0,1,11):C.UVGC_310_323,(0,1,12):C.UVGC_310_324,(0,1,5):C.UVGC_342_369,(0,2,0):C.UVGC_310_313,(0,2,1):C.UVGC_310_314,(0,2,2):C.UVGC_310_315,(0,2,3):C.UVGC_310_316,(0,2,4):C.UVGC_310_317,(0,2,6):C.UVGC_310_318,(0,2,7):C.UVGC_310_319,(0,2,8):C.UVGC_310_320,(0,2,9):C.UVGC_310_321,(0,2,10):C.UVGC_310_322,(0,2,11):C.UVGC_310_323,(0,2,12):C.UVGC_310_324,(0,2,5):C.UVGC_342_369})

V_320 = CTVertex(name = 'V_320',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ], [ [P.c, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_328_343,(0,0,2):C.UVGC_328_344,(0,0,0):C.UVGC_328_345})

V_321 = CTVertex(name = 'V_321',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_344_371,(0,0,2):C.UVGC_344_372,(0,0,1):C.UVGC_344_373})

V_322 = CTVertex(name = 'V_322',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_358_397,(0,0,2):C.UVGC_358_398,(0,0,1):C.UVGC_358_399})

V_323 = CTVertex(name = 'V_323',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_372_423,(0,0,2):C.UVGC_372_424,(0,0,1):C.UVGC_372_425})

V_324 = CTVertex(name = 'V_324',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_373_426,(0,0,2):C.UVGC_373_427,(0,0,1):C.UVGC_373_428})

V_325 = CTVertex(name = 'V_325',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_365_410,(0,0,2):C.UVGC_365_411,(0,0,1):C.UVGC_365_412})

V_326 = CTVertex(name = 'V_326',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.d, P.g] ], [ [P.c, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_335_356,(0,0,2):C.UVGC_335_357,(0,0,0):C.UVGC_335_358})

V_327 = CTVertex(name = 'V_327',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_382_445,(0,0,2):C.UVGC_382_446,(0,0,1):C.UVGC_382_447})

V_328 = CTVertex(name = 'V_328',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_351_384,(0,0,2):C.UVGC_351_385,(0,0,1):C.UVGC_351_386})

V_329 = CTVertex(name = 'V_329',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_385_454,(0,0,2):C.UVGC_385_455,(0,0,1):C.UVGC_385_456})

V_330 = CTVertex(name = 'V_330',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_320_335,(0,1,0):C.UVGC_321_336})

V_331 = CTVertex(name = 'V_331',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_359_400,(0,1,0):C.UVGC_360_401})

V_332 = CTVertex(name = 'V_332',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_374_429,(0,1,0):C.UVGC_375_430})

V_333 = CTVertex(name = 'V_333',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_312_327,(0,1,0):C.UVGC_313_328})

V_334 = CTVertex(name = 'V_334',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_329_346,(0,1,0):C.UVGC_330_347})

V_335 = CTVertex(name = 'V_335',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_345_374,(0,1,0):C.UVGC_346_375})

V_336 = CTVertex(name = 'V_336',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_311_326,(0,2,0):C.UVGC_311_326,(0,1,0):C.UVGC_308_311,(0,3,0):C.UVGC_308_311})

V_337 = CTVertex(name = 'V_337',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_319_334,(0,2,0):C.UVGC_319_334,(0,1,0):C.UVGC_316_331,(0,3,0):C.UVGC_316_331})

V_338 = CTVertex(name = 'V_338',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_327_342,(0,2,0):C.UVGC_327_342,(0,1,0):C.UVGC_324_339,(0,3,0):C.UVGC_324_339})

V_339 = CTVertex(name = 'V_339',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_343_370,(0,2,0):C.UVGC_343_370,(0,1,0):C.UVGC_340_367,(0,3,0):C.UVGC_340_367})

V_340 = CTVertex(name = 'V_340',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_357_396,(0,2,0):C.UVGC_357_396,(0,1,0):C.UVGC_354_393,(0,3,0):C.UVGC_354_393})

V_341 = CTVertex(name = 'V_341',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_371_422,(0,2,0):C.UVGC_371_422,(0,1,0):C.UVGC_368_419,(0,3,0):C.UVGC_368_419})

V_342 = CTVertex(name = 'V_342',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xd1] ] ],
                 couplings = {(0,0,0):C.UVGC_338_365,(0,1,0):C.UVGC_239_47})

V_343 = CTVertex(name = 'V_343',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xu1] ] ],
                 couplings = {(0,0,0):C.UVGC_388_463,(0,1,0):C.UVGC_269_137})

V_344 = CTVertex(name = 'V_344',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xd2] ] ],
                 couplings = {(0,0,0):C.UVGC_339_366,(0,1,0):C.UVGC_253_108})

V_345 = CTVertex(name = 'V_345',
                 type = 'UV',
                 particles = [ P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_403_582,(0,1,0):C.UVGC_273_140})

V_346 = CTVertex(name = 'V_346',
                 type = 'UV',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV2, L.VV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.c] ], [ [P.d] ], [ [P.g] ], [ [P.ghG] ], [ [P.s] ], [ [P.t] ], [ [P.u] ], [ [P.Xd1] ], [ [P.Xd2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_390_474,(0,0,1):C.UVGC_390_475,(0,0,2):C.UVGC_390_476,(0,0,3):C.UVGC_390_477,(0,0,4):C.UVGC_390_478,(0,0,5):C.UVGC_390_479,(0,0,6):C.UVGC_390_480,(0,0,7):C.UVGC_390_481,(0,0,8):C.UVGC_390_482,(0,0,9):C.UVGC_390_483,(0,0,10):C.UVGC_390_484,(0,0,11):C.UVGC_390_485,(0,1,10):C.UVGC_217_9,(0,1,11):C.UVGC_217_10,(0,2,0):C.UVGC_389_464,(0,2,1):C.UVGC_389_465,(0,2,2):C.UVGC_389_466,(0,2,5):C.UVGC_389_467,(0,2,6):C.UVGC_389_468,(0,2,7):C.UVGC_389_469,(0,2,8):C.UVGC_389_470,(0,2,9):C.UVGC_389_471,(0,2,10):C.UVGC_389_472,(0,2,11):C.UVGC_389_473})

V_347 = CTVertex(name = 'V_347',
                 type = 'UV',
                 particles = [ P.g, P.g, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVS1 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_231_40,(0,0,1):C.UVGC_231_41})

V_348 = CTVertex(name = 'V_348',
                 type = 'UV',
                 particles = [ P.a, P.a, P.g, P.g ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xu1], [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_221_17,(0,1,0):C.UVGC_221_17,(0,2,0):C.UVGC_221_17})

V_349 = CTVertex(name = 'V_349',
                 type = 'UV',
                 particles = [ P.a, P.g, P.g, P.Z ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_229_36,(0,0,1):C.UVGC_229_37,(0,1,0):C.UVGC_229_36,(0,1,1):C.UVGC_229_37,(0,2,0):C.UVGC_229_36,(0,2,1):C.UVGC_229_37})

V_350 = CTVertex(name = 'V_350',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Z, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu1, P.Xu2] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_283_150,(0,0,2):C.UVGC_283_151,(0,0,1):C.UVGC_283_152,(0,1,0):C.UVGC_283_150,(0,1,2):C.UVGC_283_151,(0,1,1):C.UVGC_283_152,(0,2,0):C.UVGC_282_147,(0,2,2):C.UVGC_282_148,(0,2,1):C.UVGC_282_149})

V_351 = CTVertex(name = 'V_351',
                 type = 'UV',
                 particles = [ P.g, P.g, P.W__minus__, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xd2, P.Xu1] ], [ [P.Xd2, P.Xu2] ], [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_281_145,(0,0,1):C.UVGC_281_146,(0,1,0):C.UVGC_281_145,(0,1,1):C.UVGC_281_146,(0,2,2):C.UVGC_280_141,(0,2,3):C.UVGC_280_142,(0,2,0):C.UVGC_280_143,(0,2,1):C.UVGC_280_144})

V_352 = CTVertex(name = 'V_352',
                 type = 'UV',
                 particles = [ P.a, P.g, P.g, P.g ],
                 color = [ 'd(2,3,4)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xu1], [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_222_18,(0,1,0):C.UVGC_222_18,(0,2,0):C.UVGC_222_18})

V_353 = CTVertex(name = 'V_353',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g, P.Z ],
                 color = [ 'd(1,2,3)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_230_38,(0,0,1):C.UVGC_230_39,(0,1,0):C.UVGC_230_38,(0,1,1):C.UVGC_230_39,(0,2,0):C.UVGC_230_38,(0,2,1):C.UVGC_230_39})

V_354 = CTVertex(name = 'V_354',
                 type = 'UV',
                 particles = [ P.g, P.g, P.H, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_219_15,(0,0,1):C.UVGC_219_16})

V_355 = CTVertex(name = 'V_355',
                 type = 'UV',
                 particles = [ P.g, P.g, P.G0, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_219_15,(0,0,1):C.UVGC_219_16})

V_356 = CTVertex(name = 'V_356',
                 type = 'UV',
                 particles = [ P.g, P.g, P.G__minus__, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.Xu1] ], [ [P.Xu2] ] ],
                 couplings = {(0,0,0):C.UVGC_219_15,(0,0,1):C.UVGC_219_16})

V_357 = CTVertex(name = 'V_357',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1__tilde__, P.Xd1, P.Xd1 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_285_158,(1,0,0):C.UVGC_285_159,(1,0,3):C.UVGC_285_160,(1,0,5):C.UVGC_285_161,(1,0,1):C.UVGC_285_162,(1,0,4):C.UVGC_285_163,(0,0,2):C.UVGC_285_158,(0,0,0):C.UVGC_285_159,(0,0,3):C.UVGC_285_160,(0,0,5):C.UVGC_285_161,(0,0,1):C.UVGC_285_162,(0,0,4):C.UVGC_285_163})

V_358 = CTVertex(name = 'V_358',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.a, P.g, P.Xd1, P.Xu1] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Xu1] ], [ [P.g, P.Xd1, P.Xu1, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.UVGC_292_204,(1,0,0):C.UVGC_292_205,(1,0,5):C.UVGC_292_206,(1,0,9):C.UVGC_292_207,(1,0,11):C.UVGC_292_208,(1,0,1):C.UVGC_292_209,(1,0,3):C.UVGC_292_210,(1,0,6):C.UVGC_292_211,(1,0,8):C.UVGC_292_212,(1,0,10):C.UVGC_292_213,(1,0,2):C.UVGC_292_214,(1,0,7):C.UVGC_292_215,(0,0,4):C.UVGC_291_192,(0,0,0):C.UVGC_291_193,(0,0,5):C.UVGC_291_194,(0,0,9):C.UVGC_291_195,(0,0,11):C.UVGC_291_196,(0,0,1):C.UVGC_291_197,(0,0,3):C.UVGC_291_198,(0,0,6):C.UVGC_291_199,(0,0,8):C.UVGC_291_200,(0,0,10):C.UVGC_291_201,(0,0,2):C.UVGC_291_202,(0,0,7):C.UVGC_291_203})

V_359 = CTVertex(name = 'V_359',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu1, P.Xu1 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_287_166,(1,0,0):C.UVGC_287_167,(1,0,3):C.UVGC_287_168,(1,0,5):C.UVGC_287_169,(1,0,1):C.UVGC_287_170,(1,0,4):C.UVGC_287_171,(0,0,2):C.UVGC_287_166,(0,0,0):C.UVGC_287_167,(0,0,3):C.UVGC_287_168,(0,0,5):C.UVGC_287_169,(0,0,1):C.UVGC_287_170,(0,0,4):C.UVGC_287_171})

V_360 = CTVertex(name = 'V_360',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xd2__tilde__, P.Xd2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1], [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd1, P.Xd2] ], [ [P.g] ], [ [P.g, P.Xd1], [P.g, P.Xd2] ], [ [P.g, P.Xd1, P.Xd2] ], [ [P.g, P.Xd1, P.Xd2, P.Z] ], [ [P.g, P.Xd1, P.Z], [P.g, P.Xd2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_290_183,(1,0,0):C.UVGC_290_184,(1,0,4):C.UVGC_290_185,(1,0,8):C.UVGC_290_186,(1,0,1):C.UVGC_290_187,(1,0,5):C.UVGC_290_188,(1,0,7):C.UVGC_290_189,(1,0,2):C.UVGC_290_190,(1,0,6):C.UVGC_290_191,(0,0,3):C.UVGC_289_174,(0,0,0):C.UVGC_289_175,(0,0,4):C.UVGC_289_176,(0,0,8):C.UVGC_289_177,(0,0,1):C.UVGC_289_178,(0,0,5):C.UVGC_289_179,(0,0,7):C.UVGC_289_180,(0,0,2):C.UVGC_289_181,(0,0,6):C.UVGC_289_182})

V_361 = CTVertex(name = 'V_361',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1__tilde__, P.Xu1 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd2, P.Xu1] ], [ [P.a, P.g, P.Xu1] ], [ [P.g] ], [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1] ], [ [P.g, P.W__plus__, P.Xu1] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu1] ], [ [P.g, P.Xd2, P.Xu1, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.UVGC_292_204,(1,0,0):C.UVGC_292_205,(1,0,5):C.UVGC_302_274,(1,0,9):C.UVGC_292_206,(1,0,13):C.UVGC_292_207,(1,0,15):C.UVGC_302_275,(1,0,1):C.UVGC_292_209,(1,0,3):C.UVGC_292_210,(1,0,6):C.UVGC_302_276,(1,0,8):C.UVGC_302_277,(1,0,10):C.UVGC_292_211,(1,0,12):C.UVGC_302_278,(1,0,14):C.UVGC_302_279,(1,0,2):C.UVGC_292_214,(1,0,7):C.UVGC_302_280,(1,0,11):C.UVGC_302_281,(0,0,4):C.UVGC_291_192,(0,0,0):C.UVGC_291_193,(0,0,5):C.UVGC_301_266,(0,0,9):C.UVGC_291_194,(0,0,13):C.UVGC_291_195,(0,0,15):C.UVGC_301_267,(0,0,1):C.UVGC_291_197,(0,0,3):C.UVGC_291_198,(0,0,6):C.UVGC_301_268,(0,0,8):C.UVGC_301_269,(0,0,10):C.UVGC_291_199,(0,0,12):C.UVGC_301_270,(0,0,14):C.UVGC_301_271,(0,0,2):C.UVGC_291_202,(0,0,7):C.UVGC_301_272,(0,0,11):C.UVGC_301_273})

V_362 = CTVertex(name = 'V_362',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2__tilde__, P.Xd2, P.Xd2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.g] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_285_158,(1,0,0):C.UVGC_285_159,(1,0,3):C.UVGC_285_160,(1,0,5):C.UVGC_286_164,(1,0,1):C.UVGC_285_162,(1,0,4):C.UVGC_286_165,(0,0,2):C.UVGC_285_158,(0,0,0):C.UVGC_285_159,(0,0,3):C.UVGC_285_160,(0,0,5):C.UVGC_286_164,(0,0,1):C.UVGC_285_162,(0,0,4):C.UVGC_286_165})

V_363 = CTVertex(name = 'V_363',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1, P.Xu1, P.Z], [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_294_220,(1,0,1):C.UVGC_294_221,(1,0,2):C.UVGC_294_222,(1,0,0):C.UVGC_294_223,(0,0,3):C.UVGC_293_216,(0,0,1):C.UVGC_293_217,(0,0,2):C.UVGC_293_218,(0,0,0):C.UVGC_293_219})

V_364 = CTVertex(name = 'V_364',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu1, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_304_285,(1,0,1):C.UVGC_304_286,(1,0,2):C.UVGC_304_287,(1,0,0):C.UVGC_304_288,(0,0,3):C.UVGC_304_285,(0,0,1):C.UVGC_304_286,(0,0,2):C.UVGC_304_287,(0,0,0):C.UVGC_304_288})

V_365 = CTVertex(name = 'V_365',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1], [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1], [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Z], [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,0):C.UVGC_300_257,(1,0,8):C.UVGC_300_258,(1,0,1):C.UVGC_300_259,(1,0,3):C.UVGC_300_260,(1,0,6):C.UVGC_300_261,(1,0,7):C.UVGC_300_262,(1,0,2):C.UVGC_300_263,(1,0,4):C.UVGC_300_264,(1,0,5):C.UVGC_300_265,(0,0,0):C.UVGC_299_248,(0,0,8):C.UVGC_299_249,(0,0,1):C.UVGC_299_250,(0,0,3):C.UVGC_299_251,(0,0,6):C.UVGC_299_252,(0,0,7):C.UVGC_299_253,(0,0,2):C.UVGC_299_254,(0,0,4):C.UVGC_299_255,(0,0,5):C.UVGC_299_256})

V_366 = CTVertex(name = 'V_366',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_303_282,(1,0,1):C.UVGC_303_283,(1,0,0):C.UVGC_303_284,(0,0,2):C.UVGC_303_282,(0,0,1):C.UVGC_303_283,(0,0,0):C.UVGC_303_284})

V_367 = CTVertex(name = 'V_367',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xd1, P.Xu1, P.Z], [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_294_220,(1,0,1):C.UVGC_294_221,(1,0,2):C.UVGC_294_222,(1,0,0):C.UVGC_294_223,(0,0,3):C.UVGC_293_216,(0,0,1):C.UVGC_293_217,(0,0,2):C.UVGC_293_218,(0,0,0):C.UVGC_293_219})

V_368 = CTVertex(name = 'V_368',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_304_285,(1,0,1):C.UVGC_304_286,(1,0,2):C.UVGC_304_287,(1,0,0):C.UVGC_304_288,(0,0,3):C.UVGC_304_285,(0,0,1):C.UVGC_304_286,(0,0,2):C.UVGC_304_287,(0,0,0):C.UVGC_304_288})

V_369 = CTVertex(name = 'V_369',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu1, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu1], [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1], [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu1, P.Xu2] ], [ [P.g, P.Xd2, P.Xu1, P.Z], [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,0):C.UVGC_300_257,(1,0,8):C.UVGC_300_258,(1,0,1):C.UVGC_300_259,(1,0,3):C.UVGC_300_260,(1,0,6):C.UVGC_300_261,(1,0,7):C.UVGC_300_262,(1,0,2):C.UVGC_300_263,(1,0,4):C.UVGC_300_264,(1,0,5):C.UVGC_300_265,(0,0,0):C.UVGC_299_248,(0,0,8):C.UVGC_299_249,(0,0,1):C.UVGC_299_250,(0,0,3):C.UVGC_299_251,(0,0,6):C.UVGC_299_252,(0,0,7):C.UVGC_299_253,(0,0,2):C.UVGC_299_254,(0,0,4):C.UVGC_299_255,(0,0,5):C.UVGC_299_256})

V_370 = CTVertex(name = 'V_370',
                 type = 'UV',
                 particles = [ P.Xd1__tilde__, P.Xd1, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd1] ], [ [P.a, P.g, P.Xd1, P.Xu2] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xd1] ], [ [P.g, P.Xd1, P.Xu2] ], [ [P.g, P.Xd1, P.Xu2, P.Z] ], [ [P.g, P.Xd1, P.Z] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.UVGC_292_204,(1,0,0):C.UVGC_292_205,(1,0,5):C.UVGC_292_206,(1,0,9):C.UVGC_292_207,(1,0,11):C.UVGC_296_228,(1,0,1):C.UVGC_292_209,(1,0,3):C.UVGC_292_210,(1,0,6):C.UVGC_292_211,(1,0,8):C.UVGC_296_229,(1,0,10):C.UVGC_296_230,(1,0,2):C.UVGC_292_214,(1,0,7):C.UVGC_296_231,(0,0,4):C.UVGC_291_192,(0,0,0):C.UVGC_291_193,(0,0,5):C.UVGC_291_194,(0,0,9):C.UVGC_291_195,(0,0,11):C.UVGC_295_224,(0,0,1):C.UVGC_291_197,(0,0,3):C.UVGC_291_198,(0,0,6):C.UVGC_291_199,(0,0,8):C.UVGC_295_225,(0,0,10):C.UVGC_295_226,(0,0,2):C.UVGC_291_202,(0,0,7):C.UVGC_295_227})

V_371 = CTVertex(name = 'V_371',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu1, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu1], [P.a, P.g, P.Xu2] ], [ [P.a, P.g, P.Xu1, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xu1], [P.g, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2] ], [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_307_302,(1,0,0):C.UVGC_307_303,(1,0,4):C.UVGC_307_304,(1,0,8):C.UVGC_307_305,(1,0,1):C.UVGC_307_306,(1,0,5):C.UVGC_307_307,(1,0,7):C.UVGC_307_308,(1,0,2):C.UVGC_307_309,(1,0,6):C.UVGC_307_310,(0,0,3):C.UVGC_306_293,(0,0,0):C.UVGC_306_294,(0,0,4):C.UVGC_306_295,(0,0,8):C.UVGC_306_296,(0,0,1):C.UVGC_306_297,(0,0,5):C.UVGC_306_298,(0,0,7):C.UVGC_306_299,(0,0,2):C.UVGC_306_300,(0,0,6):C.UVGC_306_301})

V_372 = CTVertex(name = 'V_372',
                 type = 'UV',
                 particles = [ P.Xd2__tilde__, P.Xd2, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xd2] ], [ [P.a, P.g, P.Xd2, P.Xu2] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.W__plus__] ], [ [P.g, P.W__plus__, P.Xd2] ], [ [P.g, P.W__plus__, P.Xd2, P.Xu2] ], [ [P.g, P.W__plus__, P.Xu2] ], [ [P.g, P.Xd2] ], [ [P.g, P.Xd2, P.Xu2] ], [ [P.g, P.Xd2, P.Xu2, P.Z] ], [ [P.g, P.Xd2, P.Z] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,4):C.UVGC_292_204,(1,0,0):C.UVGC_292_205,(1,0,5):C.UVGC_298_240,(1,0,9):C.UVGC_292_206,(1,0,13):C.UVGC_292_207,(1,0,15):C.UVGC_298_241,(1,0,1):C.UVGC_292_209,(1,0,3):C.UVGC_292_210,(1,0,6):C.UVGC_298_242,(1,0,8):C.UVGC_298_243,(1,0,10):C.UVGC_292_211,(1,0,12):C.UVGC_298_244,(1,0,14):C.UVGC_298_245,(1,0,2):C.UVGC_292_214,(1,0,7):C.UVGC_298_246,(1,0,11):C.UVGC_298_247,(0,0,4):C.UVGC_291_192,(0,0,0):C.UVGC_291_193,(0,0,5):C.UVGC_297_232,(0,0,9):C.UVGC_291_194,(0,0,13):C.UVGC_291_195,(0,0,15):C.UVGC_297_233,(0,0,1):C.UVGC_291_197,(0,0,3):C.UVGC_291_198,(0,0,6):C.UVGC_297_234,(0,0,8):C.UVGC_297_235,(0,0,10):C.UVGC_291_199,(0,0,12):C.UVGC_297_236,(0,0,14):C.UVGC_297_237,(0,0,2):C.UVGC_291_202,(0,0,7):C.UVGC_297_238,(0,0,11):C.UVGC_297_239})

V_373 = CTVertex(name = 'V_373',
                 type = 'UV',
                 particles = [ P.Xu1__tilde__, P.Xu2__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_305_289,(1,0,1):C.UVGC_305_290,(1,0,2):C.UVGC_305_291,(1,0,0):C.UVGC_305_292,(0,0,3):C.UVGC_305_289,(0,0,1):C.UVGC_305_290,(0,0,2):C.UVGC_305_291,(0,0,0):C.UVGC_305_292})

V_374 = CTVertex(name = 'V_374',
                 type = 'UV',
                 particles = [ P.Xu1, P.Xu1, P.Xu2__tilde__, P.Xu2__tilde__ ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z], [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_303_282,(1,0,1):C.UVGC_303_283,(1,0,0):C.UVGC_303_284,(0,0,2):C.UVGC_303_282,(0,0,1):C.UVGC_303_283,(0,0,0):C.UVGC_303_284})

V_375 = CTVertex(name = 'V_375',
                 type = 'UV',
                 particles = [ P.Xu1, P.Xu2__tilde__, P.Xu2__tilde__, P.Xu2 ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.g, P.Xu1, P.Xu2, P.Z] ], [ [P.g, P.Xu1, P.Z] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,3):C.UVGC_305_289,(1,0,1):C.UVGC_305_290,(1,0,2):C.UVGC_305_291,(1,0,0):C.UVGC_305_292,(0,0,3):C.UVGC_305_289,(0,0,1):C.UVGC_305_290,(0,0,2):C.UVGC_305_291,(0,0,0):C.UVGC_305_292})

V_376 = CTVertex(name = 'V_376',
                 type = 'UV',
                 particles = [ P.Xu2__tilde__, P.Xu2__tilde__, P.Xu2, P.Xu2 ],
                 color = [ 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.SSSS1 ],
                 loop_particles = [ [ [P.a, P.g] ], [ [P.a, P.g, P.Xu2] ], [ [P.g] ], [ [P.g, P.Xu2] ], [ [P.g, P.Xu2, P.Z] ], [ [P.g, P.Z] ] ],
                 couplings = {(1,0,2):C.UVGC_287_166,(1,0,0):C.UVGC_287_167,(1,0,3):C.UVGC_287_168,(1,0,5):C.UVGC_288_172,(1,0,1):C.UVGC_287_170,(1,0,4):C.UVGC_288_173,(0,0,2):C.UVGC_287_166,(0,0,0):C.UVGC_287_167,(0,0,3):C.UVGC_287_168,(0,0,5):C.UVGC_288_172,(0,0,1):C.UVGC_287_170,(0,0,4):C.UVGC_288_173})

