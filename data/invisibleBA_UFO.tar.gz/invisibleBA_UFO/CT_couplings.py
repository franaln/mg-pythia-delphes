# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 11.3.0 for Linux x86 (64-bit) (March 7, 2018)
# Date: Thu 9 Jun 2022 16:25:11


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



